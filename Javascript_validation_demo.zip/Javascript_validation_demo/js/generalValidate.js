// BEGIN GENERAL VALIDATE

// Define regular expression objects

// valid ssn nnn-nn-nnnn
var SSN_re = /^(\d{3})[-](\d{2})[-](\d{4})$/;

// valid EIN nn-nnnnnnn
var EIN_re = /^(\d{2})[-](\d{7})$/;

// one or more digits
var four_digits_re = /[0-9]{4}/;

// one or more digits
var digits_re = /[0-9]+/;

// one or more digits greater than 0
var digits_1_re = /^[1-9]+/;

// money
var money_re = /^[1-9]+([0-9])*([.]{1})([0-9]{2})$/;

// one or more digits
var non_digits_global_re = /\D+/g;

// one or more letters
var letter_re = /^[A-Za-z]+/;

// one or more letters or numbers
var alpha_re = /^[A-Za-z0-9]+/;

// one or more letters or numbers
var non_alpha_re = /\W+/g;

// one or more of any non-space character
var non_blank_re = /\S+/g;

// one or more spaces
var space_re = /\s+/g;

// e-mail
var reEMAIL = /^[\w\d]+([.\-]+[\w\d]+)*\@[\w\d]+([.\-]+[\w\d]+)*\.\w{2,4}$/

var reEMAIL2 = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*=([0-9a-z][0-9a-z-]*[0-9a-z]\.)+[a-z]{2}[mtgvu]?@([0-9a-z][0-9a-z-]*[0-9a-z]\.)+[a-z]{2}[mtgvu]?$/

var WWW_re = /^[w]{3}/;

// US Zip code
var reZIP = /^\d{5}([\-\+])*(\d{4})?$/

//  USA or Canadian Zip Code
var reUsaCanadaZip = /(^\d{5}([\-\+])*(\d{4})?$)|(^\D{1}\d{1}\D{1}\s\d{1}\D{1}\d{1}$)/;

// MM/DD/YY
var reSdate = /[0-1]+[0-9]+\/+[0-3]+[0-9]+\/+[0]+[0-9]/;

// HTML Color
var reColor = /^[#]+[0-9a-fA-F]{6}/;

//  ANY PHONE NUMBER
var reInternationalPhone = /^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,5})|(\(?\d{2,6}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$/

//  PRETTY LAX URL CHECK
var url_re = /(^http[s]*:\/\/){1}/

//  JPG JPEG PNG CHECK
var re_upload_image = /(\.bmp|\.gif|\.jpg|\.jpeg)$/i;

//  VALID UPLOAD IMAGE
function isValidUploadImg(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var upImgIsValid = sElement.value.search(re_upload_image);
	if(upImgIsValid == -1){
        sElement.value = '';
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please upload " + sErrorText + ".");
		} else {
		    alert("Please upload a valid image type\n    (i.e. JPG, JPEG, OR PNG)");
		}
		return false;
	} else {
	    return true;
	}
}

// Validate Web Link
function isURL(sElement,sErrorText){
    if(!sElement){
        alert("The URL field is undefined.");
        return false;
    }
	var urlVal = sElement.value.search(url_re);
	if(urlVal == -1){
		sElement.focus();
		alert("Please enter " + sErrorText);
		return false;
	}
	return true;
}

// Validate SSN
function isSSN(sElement){
    if(!sElement){
        alert("The SSN field is undefined.");
        return false;
    }
	var ssnVal = sElement.value.search(SSN_re);
	if(ssnVal == -1){
		sElement.focus();
		alert("Please enter a valid SSN [NNN-NN-NNNN] with no spaces before or after");
		return false;
	}
	return true;
}
// Valid HTML Color
function isColor(sElement,error){
    if(!sElement){
        alert("The Color field is undefined.");
        return false;
    }
	var colorVal = sElement.value.search(reColor);
	if(colorVal == -1){
		sElement.focus();
		alert("Please enter " + error);
		return false;
	}
	return true;
}

// Validate MM-DD-YY Date Format
function isSlashDate(sElement){
    if(!sElement){
        alert("The date field is undefined.");
        return false;
    }
	var dateVal = sElement.value.search(reSdate);
	if(dateVal == -1){
		sElement.focus();
		alert("Please enter a valid date MM/DD/YY");
		return false;
	}
	return true;
}

// Validate email field
function isMail(sElement){
    if(!sElement){
        alert("The email field is undefined.");
        return false;
    }
	//-----------------------------------//
	//	ADD CODE TO DETECT/PREVENT 'WWW' AT FRONT OF EMAIL
	//-----------------------------------//
	var emailwwwDetected = sElement.value.search(WWW_re);
	if(emailwwwDetected != -1){
		sElement.focus();
		alert("An email address CANNOT begin with 'www'\nPlease remove it.");
		return false;
	}
	//-----------------------------------//
	//	DISALLOW SPACES IN THE EMAIL ADDRESS
	//-----------------------------------//
	var emailSpaceDetected = sElement.value.search(space_re);
	if(emailSpaceDetected != -1){
		sElement.focus();
		alert("There is a space in your email address at position " + emailSpaceDetected + " \nPlease remove it.");
		return false;
	}
	var emailVal = sElement.value.search(reEMAIL);
	if(emailVal == -1){
		sElement.focus();
		alert("Please enter a valid email address.");
		return false;
	}
	return true;
}

function isLetter(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var ltrVal = sElement.value.search(letter_re);
	if(ltrVal == -1){
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText + ".");
		}
		return false;
	} else {
	    return true;
	}
}

function isMoney(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var MnyVal = sElement.value.search(money_re);
	if(MnyVal == -1){
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText + ".");
		}
		return false;
	} else {
	    return true;
	}
}

function isDigit(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var DgtVal = sElement.value.search(digits_re);
	if(DgtVal == -1){
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText + ".");
		}
		return false;
	} else {
	    return true;
	}
}

function isDigitGtrThanZero(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var DgtVal = sElement.value.search(digits_1_re);
	if(DgtVal == -1){
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText + ".");
		}
		return false;
	} else {
	    return true;
	}
}

function isFourDigits(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var DgtVal = sElement.value.search(four_digits_re);
	if(DgtVal == -1){
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText + ".");
		}
		return false;
	} else {
	    return true;
	}
}

function isAlpha(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var ltrVal = sElement.value.search(alpha_re);
	if(ltrVal == -1){
		sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText);
		}
	} else {
	    return true;
	}
}

function isPhone(sAreaCode, sPrefix, sSuffix, sPhoneOut, ErrorText){

    if((!isDigit(sAreaCode)) || (sAreaCode.value.length < 3)){
        sAreaCode.focus();
		alert("Please enter " + ErrorText +".");
		return false;
    }
    if((!isDigit(sPrefix, ErrorText)) || (sPrefix.value.length < 3)){
        sPrefix.focus();
		alert("Please enter " + ErrorText +".");
		return false;
	}
    if((!isDigit(sSuffix, ErrorText)) || (sSuffix.value.length < 4)){
        sSuffix.focus();
		alert("Please enter " + ErrorText +".");
		return false;
	}
    sPhoneOut.value = "(" + sAreaCode.value + ") " + sPrefix.value + "-" + sSuffix.value;
    return true;
}

function isZipCode(sElement, ErrorText){
    var zipVal = sElement.value.search(reZIP);
	if(zipVal == -1){
        sElement.focus();
		alert("Please enter " + ErrorText +".");
		return false;
	} else {
	    return true;
	}
}

function isUsaCanadianZipCode(sElement){
    var zipVal = sElement.value.search(reUsaCanadaZip);
	if(zipVal == -1){
        sElement.focus();
		alert("Please enter a valid U.S. Or Canadian Postal Code.");
		return false;
	} else {
	    return true;
	}
}

function isSelected(sElement, sDefault ,sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
	if(sElement.options[sElement.selectedIndex].value == sDefault){
		sElement.focus();
		alert("Please select from the list " + sErrorText);
		return false;
	}
	return true;
}

function isIdentifier(sElement1){
    var pwdVal1 = sElement1.value.search(alpha_re);
    var pwdValNonChar1 = sElement1.value.search(non_alpha_re);
	if((pwdVal1 == -1) || (pwdValNonChar1 != -1) || (sElement1.value.length < 8) || (sElement1.value.length > 30)){
		sElement1.focus();
	    alert("Please enter a Username that is 8 to 30 characters long.\nYou may use any combination of letters or numbers, but \ndo not enter spaces or other characters.");
	    return false;
	}
	return true;
}

function isPassword(sElement1, sElement2){
    var pwdVal1 = sElement1.value.search(alpha_re);
    var pwdValNonChar1 = sElement1.value.search(non_alpha_re);
	if((pwdVal1 == -1) || (pwdValNonChar1 != -1) || (sElement1.value.length < 5) || (sElement1.value.length > 20)){
		sElement1.focus();
	    alert("Your must enter a password that is 5 to 20 characters long.\nYou may use any combination of letters or numbers, but \ndo not enter spaces or other characters.");
	    return false;
	}
	if(arguments.length > 1){ // IF USING THIS FUNCTION TO COMPARE NEW PASSWORD RE-ENTRY
        var pwdVal2 = sElement2.value.search(alpha_re);
        var pwdValNonChar2 = sElement2.value.search(non_alpha_re);
        if((pwdVal2 == -1) || (pwdValNonChar2 != -1) || (sElement2.value.length < 5) || (sElement2.value.length > 20) || (sElement1.value != sElement2.value)){
        	sElement2.focus();
            alert("Your password re-entry does not match your password.");
            return false;
    	}
    }
    return true;
}

function isStrPhone(sElement){
    var phone_re = /^\([0-9]{3}\W+[0-9]{3}-[0-9]{4}\b/;
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var PhoneVal = sElement.value.search(phone_re);
	if(sElement.value == ""){
		sElement.focus();
	    alert("Please enter a valid Phone Number.\nFormat is: (111) 111-1111\n");
	    return false;
	}
	if(PhoneVal == -1){
		sElement.focus();
	    alert(sElement.value + " is an invalid Phone Number.\nFormat is: (111) 111-1111\nPlease correct your entry.\n");
	} else {
	    return true;
	}
}

function isInternationalPhone(sElement){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var IntPhoneVal = sElement.value.search(reInternationalPhone);
	if(sElement.value == ""){
		sElement.focus();
	    alert("Please enter a valid Phone Number");
	    return false;
	}
	if(IntPhoneVal == -1){
		sElement.focus();
	    alert(sElement.value + " is an invalid Phone Number");
	} else {
	    return true;
	}
}

function miUp(sElement){
    if(sElement){
        sElement.value = sElement.value.toUpperCase();
    }
    return true;
}

function IsNonBlank(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var nbVal = sElement.value.search(non_blank_re);
	if(nbVal == -1){
    //if(sElement.value.length < 5){
        sElement.focus();
		if(arguments.length > 1){
		    alert("Please enter " + sErrorText + ".");
		}
	} else {
	    return true;
	}
}

function isPaymentRadio(sElement){
	var bRadiolen = sElement.length;
	for(bRadio = 0; bRadio < bRadiolen; bRadio++){
		if(sElement[bRadio].checked){
			return true;
		}
	}
	sElement[0].focus();
	alert("Please select a payment method");
	return false;
}

function GetRadioValue(rArray){
	for (var i=0; i < rArray.length; i++){
		if (rArray[i].checked){
			return rArray[i].value;
		}
	}
	return null;
}

// ENSURE A RADIO BUTTON HAS BEEN SELECTED
function isRadioChecked(sElement, sErrorText){
    if(!sElement){
        alert("This field is undefined. It's errortext is: " + sErrorText);
        return false;
    }
    var oneChecked = false;
    for(var i = 0; i < sElement.length; i++){
    	if(sElement[i].checked){
    		oneChecked = true;
    	}
   	}
	if(!oneChecked){
		sElement[0].focus();
	    alert("Please choose " + sErrorText + ".");
		return false;
	} else {
	    return true;
	}
}

// END GENERAL VALIDATE