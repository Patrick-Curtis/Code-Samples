//-----------------------------------//
//  LIMITS LENGTH OF CHARACTERS ENTERED IN A TEXTAREA FIELD
//-----------------------------------//

function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
        alert("This text is limited to " + limitNum + " characters");
    }
    //alert("Text NOT Truncated to " + limitNum);   //  DEBUG
}
//-----------------------------------//
//  EXAMPLE USAGE
//-----------------------------------//
/*
<textarea rows="5" cols="30"
onKeyDown="limitText(this.form.element,20);"
onKeyUp="limitText(this.form.element,20);"
onBlur="limitText(this.form.element,20);"
></textarea>
*/
