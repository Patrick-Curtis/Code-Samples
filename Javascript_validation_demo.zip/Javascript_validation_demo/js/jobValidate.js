//-----------------------------------//
//  CHECKS VALIDITY OF JOB FORM ENTRIES
//  REQUIRES LOADING 'GENERALVALIDATE.JS' BEFORE
//  THIS FILE IN YOUR CALLING PAGE
//  NOTE: FORM USES FCK EDITOR
//-----------------------------------//

var isOkay = true;

aFieldList = new Array();
aFieldList[0] = "isAlpha(document.forms[\"f1\"].job_title, \"a Job Title\");"
aFieldList[1] = "isAlpha(document.forms[\"f1\"].job_keyword_1, \"at least one Keyword\");"
aFieldList[2] = "isAlpha(document.forms[\"f1\"].job_state_province, \"a State or Province\");"
aFieldList[3] = "isAlpha(document.forms[\"f1\"].job_city, \"a Job City\");"
aFieldList[4] = "isUsaCanadianZipCode(document.forms[\"f1\"].job_postal_code);"
aFieldList[5] = "isSelected(document.forms[\"f1\"].job_country_id, \"0\",\"a Country\");"
aFieldList[6] = "isSelected(document.forms[\"f1\"].job_category_id, \"0\",\"a Job Category\");"
aFieldList[7] = "isSelected(document.forms[\"f1\"].job_type_id, \"0\",\"a Job Type\");"
aFieldList[8] = "isSelected(document.forms[\"f1\"].job_skill_level_id, \"0\",\"a Skill Level\");"
aFieldList[9] = "isAlpha(document.forms[\"f1\"].job_short_description, \"a Short Job Description\");"

//  OPTIONAL OTHER FIELDS - SIMPLY ADD THESE FOR FURTHER VALIDATION
//  DON'T FORGET TO INDEX THEM PROPERLY :-)
/*
aFieldList[4] = "isAlpha(document.forms[\"f1\"].job_state_province, \"a State or Province\");"
aFieldList[2] = "isAlpha(document.forms[\"f1\"].job_city, \"a Job City\");"
aFieldList[5] = "isUsaCanadianZipCode(document.forms[\"f1\"].job_postal_code);"
aFieldList[4] = "IsNonBlank(document.forms[\"f1\"].job_long_description, \"a Long Job Description\");"
aFieldList[4] = "isRadioChecked(document.forms[\"f1\"].job_leed_certified_status, \"whether or not service is LEED certified\");"
aFieldList[7] = "isPhone(document.forms[\"f1\"].buyer_phone_day_1, document.forms[\"f1\"].buyer_phone_day_2, document.forms[\"f1\"].buyer_phone_day_3, document.forms[\"f1\"].buyer_phone_day, \"a Day Phone Number\");"
aFieldList[8] = "isMail(document.forms[\"f1\"].buyer_email);"
aFieldList[9] = "isAlpha(document.forms[\"f1\"].company_state_or_province, \"a Job State or Province\");"
aFieldList[10] = "isPassword(document.forms[\"f1\"].cartpassword1, document.forms[\"f1\"].cartpassword2);"
aFieldList[1] = "isMail(document.forms[\"f1\"].Email);"
*/

function CheckForm(){
    iLength = aFieldList.length;
    for(i = 0; i < iLength; i++){
        if(isOkay){
            //alert("i = " + i);
            isOkay = eval(aFieldList[i]);
        }
    }
    //-----------------------------------//
    //  IF COUNTRY IS USA OR CANADA
    //  REQUIRE STATE_PROVINCE, CITY, POSTAL CODE
    //  values: CAN-> 31 ; USA-> 184
    //-----------------------------------//
    //sElement.options[sElement.selectedIndex].value == sDefault
    if(isOkay){
        if(
        (document.forms.f1['job_country_id'].options[document.forms.f1['job_country_id'].selectedIndex].value == 31)
        ||
        (document.forms.f1['job_country_id'].options[document.forms.f1['job_country_id'].selectedIndex].value == 184)
        ){
            isOkay = isAlpha(document.forms["f1"].job_state_province, "a State or Province");
            if(isOkay){
                isOkay = isAlpha(document.forms["f1"].job_city, "a City");
            }
            if(isOkay){
                isOkay = isUsaCanadianZipCode(document.forms["f1"].job_postal_code);
            }
        }
    }
/*
    if(isOkay){
        var txt1 = get_box_content('job_long_description');
        if(txt1.length < 3){
            //alert(txt1);  //  DEBUG
            alert("Please enter a long job decsription");
            document.forms["f1"].job_long_description.focus();
            isOkay = true;
            return false;
        }
    }
*/
    if(isOkay){
        //alert("Form completed!");
        document.forms["f1"].submit();
    } else {
        isOkay = true;
        return false;
    }
}
function get_box_content(fieldname) {
      var oEditor = FCKeditorAPI.GetInstance(fieldname);
      //alert(oEditor.GetXHTML(true));
      return oEditor.GetXHTML(true);
}
