// CHECKS VALIDITY OF FORM ENTRIES
// REQUIRES LOADING 'GENERALVALIDATE.JS' BEFORE
// THIS FILE IN YOUR CALLING PAGE

//-----------------------------------//
//	ESTABLISH AN ARRAY OF THE FIELDS YOU WANT TO CHECK
//	NOTE THAT THE FORM IS NAMED "f1"
//	CHANGE THIS HERE OR, EASIER, CHANGE THE FORM'S NAME
//-----------------------------------//
var isOkay = true;

aFieldList = new Array();
aFieldList[0] = "isAlpha(document.forms[\"f1\"].Name, \"a Name\");"
aFieldList[1] = "isAlpha(document.forms[\"f1\"].Address, \"an Address\");"
aFieldList[2] = "isAlpha(document.forms[\"f1\"].City, \"a City\");"
aFieldList[3] = "isSelected(document.forms[\"f1\"].State, \"0\",\"a State\");"
aFieldList[4] = "isZipCode(document.forms[\"f1\"].Zip, \"a valid Zip Code\");"
aFieldList[5] = "isMail(document.forms[\"f1\"].Email);"
aFieldList[6] = "isRadioChecked(document.forms[\"f1\"].yesnomaybe, \"a decision\");"

//-----------------------------------//
//	RUN CHECK ON ARRAY FIELDS
//-----------------------------------//
function CheckForm(){
    iLength = aFieldList.length;
    for(i = 0; i < iLength; i++){
        if(isOkay){
            //alert("i = " + i);
            isOkay = eval(aFieldList[i]);
        }
    }
	//-----------------------------------//
	//	FINAL CHECK
	//	COMMENT OUT THE ALERT MESSAGE AND
	//	UNCOMMENT THE FORM SENDING CODE BENEATH IT
	//-----------------------------------//
    if(isOkay){
		alert("Form completed!");
		//document.forms["f1"].submit();
    } else {
        isOkay = true;
        return false;
    }
}
