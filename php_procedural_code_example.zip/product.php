<?
//-----------------------------------//
// HAVE TO INCLUDE 'DB.INC' IN
// THE FILE THAT CALLS THIS ONE
//
// ADMIN FUNCTIONS ARE IN THE INC
// FILE OF SAME NAME IN THE
// /instructor2/inc directory
//-----------------------------------//

function ReadProduct($id) {
	$id_check = db_num_rows(db_query("select * from product WHERE product_id = '$id'"));
	if($id_check) {
		return db_fetch_array(db_query("select * from product WHERE product_id = '$id'"));
	}
 	return false;
} // END   R e a d P r o d u c t ( $ i d )



//Need to move towards associative arrays to accomodate changes to the database ...Joe
function ReadProductAssoc($id) {
	$id_check = db_num_rows(db_query("select * from product WHERE product_id = '$id'"));
	if($id_check) {
		return mysql_fetch_assoc(db_query("select * from product WHERE product_id = '$id'"));
	}
 	return false;
}

//-----------------------------------//
//	RETRIEVE PRODUCT INFO FROM CODE ONLY
//-----------------------------------//
function ReadProductbyProductCode($id) {
	$id_check = db_num_rows(db_query("select * from product WHERE product_code = '$id'"));
	if($id_check) {
		return db_fetch_array(db_query("select * from product WHERE product_code = '$id'"));
	}
 	return false;
} // END   R e a d P r o d u c t ( $ i d )

function PrintProductTitle($product_id){
    $query = db_query("SELECT * FROM product WHERE product_id='$product_id'");
    $aRet = db_fetch_array($query);
    return $aRet['product_title'];
}

function PrintProductTitlebyProductCode($product_code){
    $query = db_query("SELECT * FROM product WHERE product_code='$product_code'");
    $aRet = db_fetch_array($query);
    return $aRet['product_title'];
}

function GetCategoryProducts($category_id){
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where category.category_id = '$category_id'
			and product.product_sort > 0.0

			order by product.product_sort,category.category_title,category.category_year,product.product_title
			";
			//group by category.category_title,category.category_year,product.product_title,product.product_id
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	} else {
		return false;
	}
}

function GetCategoryProductsByTitleAndYear($title,$year){

	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where category.category_title like '%$title%'
			and category.category_year = '$year'
			and product.product_sort > 0.0

			order by product.product_sort,category.category_title,category.category_year,product.product_type
			";
			//group by category.category_title,category.category_year,product.product_title,product.product_type,product.product_id
        //echo "$sql<br>";    //    DEBUG
	    //print $sql;
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	} else {
		return false;
	}
}

function GetCourseProductsByTitleAndYear($title,$year){
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where category.category_title = '$title'
			and category.category_year = '$year'
			and product.product_type = 'Course'
			and product.product_sort > 0.0

			order by product.product_sort,category.category_title,category.category_year,product.product_code
			";
			//group by category.category_title,category.category_year,product.product_code,product.product_title,product.product_id
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	}
	return false;
}

function GetExamCategoryProductsByTitle($title,$year,$JorM){
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where category.category_title like '%$title%'
			and (product.product_title like '%$JorM%' or product.product_code = '02EXB')
			and category.category_year = '$year'
			and product.product_sort > 0.0

			order by product.product_sort, category.category_title,category.category_year,product.product_type,product.product_title
			";
			//group by category.category_title,category.category_year,product.product_title,product.product_type,product.product_id
	//print $sql; exit;
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	} else {
		return false;
	}
}

function GetLibraryProductsByTitleAndYear($title,$year){
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where category.category_title = '$title'
			and category.category_year = '$year'
			and product.product_type = 'Library'
			and product.product_sort > 0.0

			order by product.product_sort,category.category_title,category.category_year,product.product_code
			";
			//group by category.category_title,category.category_year,product.product_code,product.product_title,product.product_id
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	}
	return false;
}

function GetOtherProductsByTitleAndYear($title,$year){
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where category.category_title like '%$title%'
			and category.category_year = '$year'
			and product.product_type = 'Other'
			and product.product_sort > 0.0

			order by product.product_sort, category.category_title,category.category_year,product.product_type,product.product_title
			";
			//group by category.category_title,category.category_year,product.product_title,product.product_type,product.product_id
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	} else {
		return false;
	}
}

function PrintCategoryBookList($category_id,$year){
	//print "Category ID is: $category_id<br>";
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
		where category.category_id = '$category_id'
		and category.category_year = '$year'
		and product.product_type = 'Book'
		and product.product_sort > 0.0
		order by product.product_sort
	";
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		$str = '
		<table width="100%" cellspacing="0" cellpadding="2">
		<tr>
		<td class="bodybold" colspan="2" bgcolor="#EFEFEF" height="25">
		&nbsp;
		Title</td>
		<td class="bodybold" bgcolor="#EFEFEF">Description</td>
		</tr>
		';
		while($row = db_fetch_array($resID)){
			$str .= '
			<tr valign="top">
			<td class="bodynormal">
			';
			if($row['product_type'] != "Library"){
				$str .= '<a href="bookitem.php?id='.$row['product_id'].'&year='.$year.'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>';
			} else {
				$str .= '<a href="bookitem.php?id='.$row['product_id'].'&year='.$year.'">'.FormatImageMain($row['product_image'],"2.5").'</a>';
			}
			$str .= '
			</td>
			<td class="bodynormal">
			<a href="bookitem.php?id='.$row['product_id'].'&year='.$year.'">'.$row['product_title']."<br><br>".$row['product_code'].'</a>
			</td>
			<td class="bodynormal">
			</td>
			</tr>
			<tr valign="top">
			<td class="bodynormal" colspan="4">
			<hr size="1" noshade>
			</td>
			</tr>
			';
		}
		$str .= '</table>';
	} else {
		$str = "There are no products in this category ";
	}
	return $str;
}

function  PrintProductCategoryBookList($resID,$from,$title,$searchtext){
	if(!$resID){
		return "<br><center><span class='bodynormal'>There are no books for this category.</span></center>";
	}
	$str = '<table width="100%" cellpadding="4" cellspacing="0">';
	$str .= '
	<tr>
	<td class="bodybold"  bgcolor="#EFEFEF">
	Title
	</td>
	<td bgcolor="#EFEFEF">
	&nbsp;
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	$count = 0;
	while($row = db_fetch_array($resID)){
		if($row['product_type'] == "Book"){
		$count++;
		$str .= '
		<tr valign="top">
		<td class="bodynormal">
		<a href="bookitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>
		</td>
		<td class="bodynormal">
		<a href="bookitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.$row['product_title'].'</a><br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
		</td>
		';

			if ($row['clearanceItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else if ($row['prepubItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else {
				$str .= '
				<td class="bodynormal">
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			}

		$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="bookitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">More Info</a></span>
		<!--
		<br><center><span class="bodynormal">
		<a href="bookitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'"> Click Here for More Information</a>
		</span></center>
		-->
		';
		//-----------------------------------//
		//	8/29/2006 -PC
		//	ADD POSSIBILITY OF EXAM PREP FREE EXAM LINK
		//-----------------------------------//
		//if($row['product_exam_url']){
		if($row['category_id'] == 20){
			$str .= '
			<br><br>
			[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
			<br><br><br><br>
			';
		}

		$str .= '
		</td>
		</tr>
		';
		}
	}
	$str .= '</table>';
	//echo $count;
	return $str;
}

function PrintProductCategories($resID,$from,$year){
	if($year == '2005'){
		$images = array(
			'Electrical Calculations'		=>	'img/catalog/ECbutton2005.jpg',
			'Continuing Education'			=>	'img/catalog/CEbutton2005.jpg',
			'Electrical Theory'				=>	'img/catalog/ETbutton2005.jpg',
			'Electrical Estimating'			=>	'img/catalog/EEbutton2005.jpg',
			'Exam Preparation'				=>	'img/catalog/EPbutton2005.jpg',
			'Grounding versus Bonding'		=>	'img/catalog/GBbutton2005.jpg',
			'Low Voltage/Limited Energy'	=>	'img/catalog/LECSbutton2005.jpg',
			'Business Management'			=>	'img/catalog/BMbutton2005.jpg',
			'NEC'							=>	'img/catalog/NECbutton2005.jpg',
			'Snapz'							=>	'img/catalog/Snapzbutton2005.jpg'
		);
	} elseif($year == '2008'){
		$images = array(
			'Electrical Calculations'		=>	'img/catalog/ECbutton2005.jpg',
			'Continuing Education'			=>	'img/catalog/CEbutton2005.jpg',
			'Electrical Theory'				=>	'img/catalog/ETbutton2005.jpg',
			'Electrical Estimating'			=>	'img/catalog/EEbutton2005.jpg',
			'Exam Preparation'				=>	'img/catalog/EPbutton2005.jpg',
			'Grounding versus Bonding'		=>	'img/catalog/GBbutton2005.jpg',
			'Low Voltage/Limited Energy'	=>	'img/catalog/LECSbutton2005.jpg',
			'Business Management'			=>	'img/catalog/BMbutton2005.jpg',
			'NEC'							=>	'img/catalog/NECbutton2005.jpg',
			'Snapz'							=>	'img/catalog/Snapzbutton2005.jpg'
		);
	} else {
		$images = array(
			'Electrical Calculations'		=>	'img/catalog/ECbutton2005.jpg',
			'Continuing Education'			=>	'img/catalog/CEbutton2005.jpg',
			'Electrical Theory'				=>	'img/catalog/ETbutton2005.jpg',
			'Electrical Estimating'			=>	'img/catalog/EEbutton2005.jpg',
			'Exam Preparation'				=>	'img/catalog/EPbutton2005.jpg',
			'Grounding versus Bonding'		=>	'img/catalog/GBbutton2005.jpg',
			'Low Voltage/Limited Energy'	=>	'img/catalog/LECSbutton2005.jpg',
			'Business Management'			=>	'img/catalog/BMbutton2005.jpg',
			'NEC'							=>	'img/catalog/NECbutton2005.jpg'
		);
	}


	// Override all images to new 8/31/10  ...Joe
	$images = array(
		'Electrical Calculations'		=>	'img/catalog/Calcbutton2010.gif',
		'Electrical Theory'				=>	'img/catalog/Theorybutton2010.gif',
		'Electrical Estimating'			=>	'img/catalog/Estimatebutton2010.gif',
		'Exam Preparation'				=>	'img/catalog/ExamPrepbutton2010.gif',
		'Grounding versus Bonding'		=>	'img/catalog/GvBbutton.gif',
		'Low Voltage/Limited Energy'	=>	'img/catalog/LVbutton2010.gif',
		'Business Management'			=>	'img/catalog/BMbutton2010.gif',
		'NEC'							=>	'img/catalog/NECbutton2010.gif',
		'Snapz'							=>	'img/catalog/Snapzbutton2010.gif'
	);


	if($year == '2005'){
		$color = array("#efefef","#FFFFFF");
	} elseif($year == '2008'){
		$color = array("#efefef","#FFFFFF");
	} else {
		$color = array("#FFFFCC","#FFFFFF");
	}
	$oddeven = 0;
	if(!$resID){
		return "<center>There are no categories for this year.</center>";
	}
	$str = '
		<table width="100%" border="0" cellspacing="0" cellpadding="4">
	';
	//  2/4/2008 -PC
	//  ADD CODE FOR CHANGING CONTINUING EDUCATION LINKS
	while($row = db_fetch_array($resID)){

		//No longer display ConEd category per belynda 9-8-2010 ...Joe
		if(stristr($row['category_title'],"CONTINUING")){
			continue;
		}


		$str .= '
		<tr bgcolor="'.$color[$oddeven].'">
		<td class="bodynormal" valign="middle" height="20">
		';
        if(stristr($row['category_title'],"CONTINUING")){
    		$str_disabled .= '
    		<a href="continuingEducation.php"><img src="'.$images[$row['category_title']].'"
    		border="0"
    		alt="View all '.$row['category_title'].' products"></a>
    		<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    		<!--
    		[
    		<a href="productcategorylist.php?id='.$row['category_id'].'&from=Products&title='.$row['category_title'].'&year='.$row['category_year'].'">View All</a>
    		]
    		-->
    		</td>
    		';
        } else {
    		$str .= '
    		<a href="productcategorylist.php?id='.$row['category_id'].'&from=Products&title='.$row['category_title'].'&year='.$row['category_year'].'"><img src="'.$images[$row['category_title']].'" border="0" alt="View all '.$row['category_title'].' products"></a>
    		<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    		[
    		<a href="productcategorylist.php?id='.$row['category_id'].'&from=Products&title='.$row['category_title'].'&year='.$row['category_year'].'">View All</a>
    		]
    		</td>
    		';
        }
		$str .= '
		'.PrintProductRowCountForCategoryType($row['category_id'],$from).'
		</tr>
		';
		if($oddeven == 0){
			$oddeven = 1;
		} else {
			$oddeven = 0;
		}
	}
	$str .= '</table>';
	return $str;
}

function PrintProductRowCountForCategoryType($category_id,$from){
	$str = '';
	$producttypes = array("Book","DVD Program","Other");
	$max = sizeof($producttypes);
	for($i = 0; $i < $max; $i++){
		$sql_old =	"
			select product.*,category.category_title,category.category_year,category.category_id
			from product,category
			where category.category_id = '$category_id'
			and product.category_id = category.category_id
			and product.product_type = '".$producttypes[$i]."'
			and product.product_sort > 0.0
			order by product.product_sort,product.product_type
			";


		$sql = "

			SELECT
			 category.category_title,category.category_year
			FROM
			 product
			 INNER JOIN category ON (product.category_id=category.category_id)
			WHERE
			  (product.product_sort > 0.0) AND
			  (category.category_id = '$category_id') AND
			  (product.product_type = '".$producttypes[$i]."')
			ORDER BY
			  product.product_sort,
			  product.product_type

			";


		$resID = db_query($sql);
		$count = db_num_rows($resID);
		$row = db_fetch_array($resID);

		if(($producttypes[$i] == 'Book') && (!stristr($row['category_title'],'CONTINUING'))) {
			if($count){
				$str .= '
				<td class="bodynormal" valign="top"><br><a href="bookcategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">'.$producttypes[$i].'s</a> [ '.$count.' ]</td>';
			} else {
				$str .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].'s [ '.$count.' ]</td>';
			}
		}

		if($producttypes[$i] == 'DVD Program'){
            //-----------------------------------//
            //  1/23/2009 -PC
            //  MAKE ALL COURSE LINKS STATIC
            //  9/11/2009 -PC
            //  REMOVED FOR BELYNDA AND RETURN TO PREVIOUS CODE
            //-----------------------------------//
            if(stristr($row['category_title'],'CONTINUING')){
    			if($count){
    				//$str .= '<td class="bodynormal" valign="top"><br><a href="coursecategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">'.$producttypes[$i].'s</a> [ '.$count.' ]</td>';
    				$str_disabled .= '<td class="bodynormal" valign="top"><br><a href="continuingEducation.php">'.$producttypes[$i].'s</a> [ '.$count.' ]</td>';
    			} else {
    				$str_disabled .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].'s [ '.$count.' ]</td>';
    			}
            } else {
    			if($count){
    				$str .= '<td class="bodynormal" valign="top"><br><a href="dvdCategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">'.$producttypes[$i].'s</a> [ '.$count.' ]</td>';
    			} else {
    				$str .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].'s [ '.$count.' ]</td>';
    			}
            }
            //-----------------------------------//
            //  2/4/2008 -PC
            //  ADD POSSIBILITY OF EXAM PREP FREE EXAM LINK
            //-----------------------------------//

            /*
            if(stristr($row['category_title'],'CONTINUING')){
    			if($count){
    				$str_disabled .= '<td class="bodynormal" valign="top"><br><a href="conedu.php?id=conedugeneral">'.$producttypes[$i].'s</a> [ '.$count.' ]</td>';
    			} else {
    				$str_disabled .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].'s [ '.$count.' ]</td>';
    			}
            } else {
    			if($count){
    				$str .= '<td class="bodynormal" valign="top"><br><a href="coursecategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">'.$producttypes[$i].'s</a> [ '.$count.' ]</td>';
    			} else {
    				$str .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].'s [ '.$count.' ]</td>';
    			}
            }
		*/
		}
//-----------------------------------//
//  DON'T SHOW "OTHER" FOR CEU
//-----------------------------------//
		if(($producttypes[$i] == 'Other') &&(!stristr($row['category_title'],'CONTINUING'))){
			if($count){
				$str .= '<td class="bodynormal" valign="top"><br><a href="othercategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">'.$producttypes[$i].'</a> [ '.$count.' ]</td>';
			} else {
				$str .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].' [ '.$count.' ]</td>';
			}
		} else {
		    //$str .= '<td>&nbsp;</td>';
		}
		/*
		if($producttypes[$i] == 'Other'){
			if($count){
				$str .= '<td class="bodynormal" valign="top"><br><a href="othercategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">'.$producttypes[$i].'</a> [ '.$count.' ]</td>';
			} else {
				$str .= '<td class="bodynormal" valign="top"><br>'.$producttypes[$i].' [ '.$count.' ]</td>';
			}
		}
		*/
		if($producttypes[$i] == 'Library'){
			if($count){
				$str .= '<td class="bodynormal" valign="top"><br><a href="librarycategory.php?title='.urlencode($row['category_title']).'&year='.$row['category_year'].'&from='.$from.'">Libraries</a> [ '.$count.' ]</td>';
			} else {
				$str .= '<td class="bodynormal" valign="top"><br>Libraries [ '.$count.' ]</td>';
			}
		}
	}
	return $str;
}

function PrintProduct($product,$year,$title){
	global $PHP_SELF;
	//global $_SERVER["REQUEST_URI"];
	$str = '
	<table border="0" cellpadding="4" cellspacing="0" align="center" width="100%">
		<tr valign="top">
			<td>';


	//7-12-2010 Added stop for disabled products ...Joe
	if ($product['product_disabled']) {

		$str .= '<span class = "bluebold"><center>This product is not currently available.</center></span>
		</td></tr></table>';


		if ($product['replacement_product_id']) {
			$str .= '<span class = "bluebold"><center><a href="productitem.php?id='.$product['replacement_product_id'].'">Here is the replacement for this item</a></center></span>';
		}

		return $str;

	}






	if ($product['product_graphic_border_disabled']) {
		$str .= '<div style="float: left; position: relative; border: 1px '.$product['product_graphic_border'].' solid; background-color:'.$product['product_graphic_border'].';">'.PrintResizedImage($product['product_image'],'',1).'<div>';
	} else {
		$str .= PrintResizedImage($product['product_image'],'',1);
	}

	$str .=	'
			</td>
			<td class="bodynormal">
	';
	//-----------------------------------//
	//	8/29/2006 -PC
	//	ADD POSSIBILITY OF EXAM PREP FREE EXAM LINK
	//-----------------------------------//
	//if($product['product_exam_url']){
	/*
	if($product['category_id'] == 20){
		$str .= '
		[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
		<br>
		';
	}
	*/
	//-----------------------------------//
	//	7/5/2005 - ADD CODE TO SPLIT LONG TEXT
	//  2/10/2010 change to 4000 chars allowed
	//-----------------------------------//
	if(strlen($product['product_description_student']) < 4000){
		$str .= '
		'.xlateNewLineTab($product['product_description_student']).' &nbsp;
		<br><br>
		';
	} elseif(stristr($_SERVER["REQUEST_URI"],"ext=1")) {
		$str .= '
		'.xlateNewLineTab($product['product_description_student']).' &nbsp;
		[
		<a href="'.substr($_SERVER["REQUEST_URI"],0,-6).'">Less Information</a>
		]
		<br><br>
		';
	} else {
		$str .= '
		'.xlateNewLineTab(substr($product['product_description_student'],0,4000)).' ...
		[
		<a href="'.$_SERVER["REQUEST_URI"].'&ext=1">More Information</a>
		]
		<br><br>
		';
	}
			$str .= '
			<span class="bodybold">Product Code: </span> '.$product['product_code'].'<br>
			';
            if($product['product_ISBN']){
            $str .= '
			<span class="bodybold">ISBN: </span> '.$product['product_ISBN'].'<br>
            ';
            }
            if($product['product_ISBN2']){
			$str .= '
			<span class="bodybold">ISBN 2: </span> '.$product['product_ISBN2'].'<br>
			';
			}
			if($product['product_page_count'] != ""){
				$str .= '
				<span class="bodybold">Pages: </span> '.$product['product_page_count'].'</span><br>
				';
			}
			if($product['product_illustration_count'] != ""){
				$str .= '
				<span class="bodybold">Illustrations: </span> '.$product['product_illustration_count'].'</span><br>
				';
			}
			//-----------------------------------//
			//	4/10/2006 -PC
			//	ADD CODE TO DISPLAY NEW FIELD: PRACTICE QUESTION COUNT
			//-----------------------------------//
			if($product['product_practice_question_count'] != ""){
				$str .= '
				<span class="bodybold">Practice Questions: </span> '.$product['product_practice_question_count'].'</span><br>
				';
			}

			if ($product['clearanceItem']) {

				//$str .= '
				$str .= '
					<span class="bodybold">Price: </span> <span style="color:red;text-decoration:line-through"><span style="color:black">$'.$product['originalPrice'].'</span></span> $'.$product['product_price'].' </span>
					<br>
				';

			} else if ($product['prepubItem']) {

				//$str .= '
				$str .= '
					<span class="bodybold">Price: </span> <span style="color:red;text-decoration:line-through"><span style="color:black">$'.$product['originalPrice'].'</span></span><br><span class="bodybold">*Pre-publication Price:</span> $'.$product['product_price'].'<br>&nbsp;&nbsp;'.$product['prePubText'].'</span>
					<br>
				';
			} else {

				$str .= '<span class="bodybold">Price: </span> $'.$product['product_price'].' </span>';
			}




			if($product['product_available_date'] != ""){
				$str .= '
				<p class="redbolditalic"> This product will ship
				'.$product['product_available_date'].'
				</p>
				';
			}
			$str .= '<p><a href="cartadd.php?year='.$year.'&product_id='.$product['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" name="orderoff1" width="100" height="20" onMouseOver="orderoff1.src=\'img/catalog/order_now_on.gif\'" onMouseOut="orderoff1.src=\'img/catalog/order_now_off_yellow.gif\'" border="0" align="absmiddle"></a><br>';

			//if(HasRatings($product['product_id'])){
				//$str .= '
					//<ul><span class="bodysmall">
					//<li>[ <a href="bookratingview.php?id='.$product['product_id'].'&year='.$year.'">View Ratings</a> ]</li>
					//<li>[ <a href="bookratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product ]</a>
					//</li>
					//</ul><br><br><br><br>
				//';
			//} else {
				//$str .= '
					//<p class="bodysmall" align="center">
					//[ <a href="bookratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Book</a> ]</p>
					//</p><br><br><br><br>
				//';
			//}

			//-----------------------------------//
			//	5/6/2005 ADD CODE FOR NOTES
			//-----------------------------------//
			if($product['product_notes'] != ''){
				$str .= '
				<hr size="1" noshade>
				<span class="bluebolditalic">
				NOTE:
				</span>
				<span class="blue">
				'.DisplayText($product['product_notes']).'
				</span>
				<hr size="1" noshade>
				';
			}
			//-----------------------------------//
			//	4/12/2006 -PC
			//	ADD PRODUCT LINK
			//-----------------------------------//
			if($product['product_link_text']){
			$str .= '
				<br>
				<center>
				<span class="bodybolditalic">
				<a href="'.$product['product_link_url'].'" target="_blank">'.$product['product_link_text'].'</a>
				</span>
				</center>
				<br>
			';
			}
			$str .= '
				</td>
				</tr>
				</table>';

//-----------------------------------//
//  9/12/2010 -PC
//  ADD CODE FOR DISPLAYING CUSTOMER COMENTS
//-----------------------------------//
if($product['what_people_say'] != ""){
    $str .= '
    <div id="whatpeoplesay" style="border: 1px solid #000000; width: 300px; margin: 4px auto; padding: 4px; text-align: center;">
    <a class="ceebox" href="productComments.php?id='.$product['product_id'].'">Click here to see what customers are saying</a>
    </div>
    ';
}


	$str .= '
		<table width="100%">
		<tr>
		';
		if(($product['product_pdf_toc'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_pdf_sample'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:500; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_graphic'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:535; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_video'] != "")){
			if(stristr($product['product_video'],"mov")){
				$target = ' target="blank"';
			}
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:570; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'"'.$target.'>Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str.= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'"'.$target.'>Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['dvd_team_list'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:605; z-index:1;">
		<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="PopDVDTeam.php?id='.$product['product_id'].'" target="_blank">DVD Team</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</div>
		';
		////
			$str.= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox html" href="PopDVDTeam.php?id='.$product['product_id'].'">DVD Team</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		$str .= '
		</tr>
		</table>
	';
	if(($product['product_video'] != "")){
		if(stristr($product['product_video'],"ram")){
			$str .= '
			<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
				<tr><td class="bodynormal" align="center">
				VIEWING Sample Video FILE requires <a href="http://forms.real.com/netzip/getrde601.html?h=207.188.7.150&f=windows/RealOnePlayerV2GOLD.exe&p=RealOne+Player&oem=dl&tagtype=ie&type=dl" target="_blank">Real Media Player  [ FREE ]</a>
				</td></tr>
			</table>
			';
		}
		if(stristr($product['product_video'],"mov")){
			$str .= '
			<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
				<tr><td class="bodynormal" align="center">
				VIEWING Sample Video FILE requires <a href="http://www.apple.com/quicktime/download/" target="_blank">QuickTime Player  [ FREE ]</a>
				</td></tr>
			</table>
			';
		}
	}
	return $str;
}

function  PrintCategoryCourseList($resID,$from,$title,$searchtext){
	if(!$resID){
		return "<br><center><span class='bodynormal'>There are no Courses for this category.</span></center>";
	}

	$str = '<table width="100%" cellpadding="2" cellspacing="0">';
	$str .= '
	<tr height="25">
	<td class="bodybold" bgcolor="#EFEFEF" colspan="2">
	&nbsp;
	Title
	</td>
	<td class="bodybold" bgcolor="#EFEFEF">
	&nbsp;Type
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	while($row = db_fetch_array($resID)){
		if($row['product_type'] == "Course"){
			$str .= '
			<tr valign="top">
			<td class="bodynormal">
			<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>
			</td>
			<td class="bodynormal">
			<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.$row['product_title'].'<br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
			</td>
			<td class="bodygreenbold">
			&nbsp;'.$row['product_type'].'

			';
			if($row['product_video_type']){
				$str .= '<center><img src="img/common/videoicon2.gif"></center>';
			}

			if ($row['clearanceItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else if ($row['prepubItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else {
				$str .= '
				<td class="bodynormal">
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			}
			$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">More Info</a></span>';
			$str .= '
			</td>
			</tr>
			';
		}
	}
	$str .= '</table>';
	return $str;
}

function  PrintCategoryDVDList($resID,$from,$title,$searchtext){
	if(!$resID){
		return "<br><center><span class='bodynormal'>There are no DVD Programs for this category.</span></center>";
	}

	$str = '<table width="100%" cellpadding="2" cellspacing="0">';
	$str .= '
	<tr height="25">
	<td class="bodybold" bgcolor="#EFEFEF" colspan="2">
	&nbsp;
	Title
	</td>
	<td class="bodybold" bgcolor="#EFEFEF">
	&nbsp;Type
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	while($row = db_fetch_array($resID)){
		if($row['product_type'] == "DVD Program"){
			$str .= '
			<tr valign="top">
			<td class="bodynormal">
			<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>
			</td>
			<td class="bodynormal">
			<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.$row['product_title'].'</a><br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
			</td>
			<td class="bodygreenbold">
			&nbsp;'.$row['product_type'].'

			';
			if($row['product_video_type']){
				$str .= '<center><img src="img/common/videoicon2.gif"></center>';
			}



			if ($row['clearanceItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else if ($row['prepubItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else {
				$str .= '
				<td class="bodynormal">
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			}
			$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">More Info</a></span>';
			$str .= '
			</td>
			</tr>
			';
		}
	}
	$str .= '</table>';
	return $str;
}

function  PrintCategoryLibraryList($resID,$from,$title,$searchtext){
	if(!$resID){
		return "<br><center><span class='bodynormal'>There are no Libraries for this category.</span></center>";
	}
	$str = '<table width="100%" cellpadding="2" cellspacing="0">';
	$str .= '
	<tr height="25">
	<td class="bodybold" bgcolor="#EFEFEF" colspan="2">
	&nbsp;
	Title
	</td>
	<td class="bodybold" bgcolor="#EFEFEF">
	&nbsp;Type
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	while($row = db_fetch_array($resID)){
		if($row['product_type'] == "Library"){
			$str .= '
			<tr valign="top">
			<td class="bodynormal">
			<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>
			</td>
			<td class="bodynormal">
			<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.$row['product_title'].'</a><br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
			</td>
			<td class="bodygreenbold">
			&nbsp;'.$row['product_type'].'
			';
			if($row['product_video_type']){
				$str .= '<center><img src="img/common/videoicon2.gif"></center>';
			}

			if ($row['clearanceItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else if ($row['prepubItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else {
				$str .= '
				<td class="bodynormal">
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			}
			$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">More Info</a></span>';
			$str .= '
			</td>
			</tr>
			';
		}
	}
	$str .= '</table>';
	return $str;
}

function PrintCategoryListAll($resID){
	if(!$resID){
		return "<br><center>There are no Products for this Category and Year.</center>";
	}
	$str = '<table width="100%" cellpadding="2" cellspacing="0">';
	$str .= '
	<tr height="25">
	<td class="bodybold" bgcolor="#EFEFEF" colspan="2">
	&nbsp;
	Title
	</td>
	<td class="bodybold" bgcolor="#EFEFEF">
	&nbsp;Type
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	while($row = db_fetch_array($resID)){
	$str .= '
	<tr valign="top">
	<td class="bodynormal">';

	/* changed 6-18-2010  ...Joe
	if($row['product_type'] != "Library"){
		$str .= '<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from=All&type='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>';
	} else {
		$str .= '<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from=All&type='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>';
	}
	*/

	if ($row['product_graphic_border_disabled']) {
		$str .= '<div style="float: left; position: relative; border: 1px '.$row['product_graphic_border'].' solid; background-color:'.$row['product_graphic_border'].'; "><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from=All&type='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a></div>';
	} else {
		$str .= '<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from=All&type='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>';
	}

	$str .= '</td>
	<td class="bodynormal">
	<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from=All&type='.$row['product_type'].'">'.$row['product_title'].'</a><br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
	</td>
	<td class="bodygreenbold">
	&nbsp;'.$row['product_type'].'
	';
	if($row['product_video_type']){
		$str .= '<center><img src="img/common/videoicon2.gif"></center>';
	}
			if ($row['clearanceItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else if ($row['prepubItem']) {
				$str .= '
				<td class="bodynormal">
				&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			} else {
				$str .= '
				<td class="bodynormal">
				&nbsp;$'.$row['product_price'].'
				</td>
				<td class="blue">
				';
			}
	$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from=All&type='.$row['product_type'].'">More Info</a></span>';
	//-----------------------------------//
	//	8/29/2006 -PC
	//	ADD POSSIBILITY OF RELEVANT FREE EXAM LINK
	//-----------------------------------//
	//if($row['product_exam_url']){
	//-----------------------------------//
	//	ELECTRICAL NEC EXAM PREPARATION
	//-----------------------------------//
	if(($row['category_id'] == 20) || ($row['category_id'] == 6)){
		$str .= '
		<br><br>
		[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
		<br><br><br><br>
		';
	}
	//-----------------------------------//
	//	ELECTRICAL ESTIMATING
	//-----------------------------------//
	if(($row['category_id'] == 21) || ($row['category_id'] == 8)){
		$str .= '
		<br><br>
		[ <a href="MQE/StudentClassExamListRemote.php?cid=2" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
		<br><br><br><br>
		';
	}
	//-----------------------------------//
	//	GROUNDING VS. BONDING
	//-----------------------------------//
	if(($row['category_id'] == 22) || ($row['category_id'] == 9)){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=3" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//-----------------------------------//
	//	NEC PRODUCTS INCLUDES A VARIETY
	//	ALLOW UP TO TWO LINKS EACH IN THESE
	//-----------------------------------//
	//	05UNPP - Understanding the NEC, Volume 1 - PowerPoint
	if($row['product_id'] == 485){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05UN2PP - Understanding the NEC, Volume 2 - PowerPoint
	if($row['product_id'] == 486){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05LEPP - Low-Voltage and Power-Limited Systems - PowerPoint
	if($row['product_id'] == 488){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=4" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05GBPP - Grounding versus Bonding - PowerPoint
	if($row['product_id'] == 489){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=3" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05UND1 - Understanding the NEC, Volume 1 Articles 90-460
	if($row['product_id'] == 224){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05UN1WB - Understanding the NEC, Volume 1 Articles 90-460 Workbook
	if($row['product_id'] == 326){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05UND2 - Understanding the NEC, Volume 2 Article 500-Annex C
	if($row['product_id'] == 322){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05UN2WB - Understanding the NEC, Volume 2 Article 500-Annex C Workbook
	if($row['product_id'] == 327){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05UND3 - Understanding Volume 1, 2, and NEC Exam Practice Questions Book SAVINGS! - HAS TWO LINKS
	if($row['product_id'] == 495){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05UND12 - Understanding Volume 1 & 2 together - SAVINGS!
	if($row['product_id'] == 498){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05NCT2 - Grounding versus Bonding, Article 250 - Textbook
	if($row['product_id'] == 233){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=3" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05NCV2 - Grounding versus Bonding, Article 250 Video
	if($row['product_id'] == 386){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=3" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05NCDVD2 - Grounding versus Bonding, Article 250 DVD
	if($row['product_id'] == 259){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=3" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05GBOLP - Grounding versus Bonding (Article 250) Online Program
	if($row['product_id'] == 461){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=3" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05LE - Low-Voltage and Power-Limited Systems Textbook
	if($row['product_id'] == 409){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=4" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05LEV - Low-Voltage and Power-Limited Systems Video
	if($row['product_id'] == 411){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=4" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05LED - Low-Voltage and Power-Limited Systems DVD
	if($row['product_id'] == 410){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=4" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//	05DECO - National Electric Code Library Videos
	if($row['product_id'] == 323){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//	05DECODVD - National Electrical Code Library DVDs
	if($row['product_id'] == 384){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=5" target="_blank">Test your knowledge of Understanding the NEC, Volume 1 with our FREE 25 question quiz </a>
		]
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=6" target="_blank">Test your knowledge of Understanding the NEC, Volume 2 with our FREE 25 question quiz </a>
		]
		<br><br><br><br>
		';
	}
	//-----------------------------------//
	//	LOW VOLTAGE
	//-----------------------------------//
	if(($row['category_id'] == 25) || ($row['category_id'] == 15)){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=4" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	//-----------------------------------//
	//	ELECTRICAL THEORY
	//-----------------------------------//
	if(($row['category_id'] == 18) || ($row['category_id'] == 2)){
		$str .= '
		<br><br>
		[
		<a href="MQE/StudentClassExamListRemote.php?cid=7" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a>
		]
		<br><br><br><br>
		';
	}
	$str .= '
	</td>
	</tr>
	';
	}
	$str .= '</table>';
	return $str;
}

function  PrintCategoryOtherList($resID,$from,$title,$searchtext){
	if(!$resID){
		return "<br><center>There are no products for this category and year.</center>";
	}
	$str = '<table width="100%" cellpadding="4" cellspacing="0">';
	$str .= '
	<tr>
	<td class="bodybold" bgcolor="#EFEFEF" colspan="2">
	Title
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Type
	</td>
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	while($row = db_fetch_array($resID)){
		if($row['product_type'] == "Other"){
		$str .= '
		<tr valign="top">
		<td class="bodynormal">
		<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>
		</td>
		<td class="bodynormal">
		<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.$row['product_title'].'</a><br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
		</td>
		<td class="bodygreenbold">
		&nbsp;'.$row['product_type'].'
		';
		if($row['product_video_type']){
			$str .= '<center><img src="img/common/videoicon2.gif"></center>';
		}


		if ($row['clearanceItem']) {
			$str .= '
			<td class="bodynormal">
			&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
			&nbsp;$'.$row['product_price'].'
			</td>
			<td class="blue">
			';
		} else if ($row['prepubItem']) {
			$str .= '
			<td class="bodynormal">
			&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
			&nbsp;$'.$row['product_price'].'
			</td>
			<td class="blue">
			';
		} else {
			$str .= '
			<td class="bodynormal">
			&nbsp;$'.$row['product_price'].'
			</td>
			<td class="blue">
			';
		}

		if($row['product_description_instructor'] != ""){
			$str .= substr($row['product_description_instructor'],0,250).'<span class="bodyverdanaboldblue"> . . .</span>';
		} else {
			$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">More Info</a></span>';
		}
		$str .= '
		</td>
		</tr>
		';
		}
	}
	$str .= '</table>';
	return $str;
}

function PrintCourseProduct($product,$year){
	$str = '
	<table border="0" cellpadding="4" cellspacing="0" align="center" width="100%">
		<tr valign="top">
			<td>
			<img src="instructor2/'.$product['product_image'].'" width="230" height="250" border="0">
			</td>
			<td class="bodynormal">
			';
		//-----------------------------------//
		//	8/29/2006 -PC
		//	ADD POSSIBILITY OF EXAM PREP FREE EXAM LINK
		//-----------------------------------//
		//if($product['product_exam_url']){
		/*
		if($product['category_id'] == 20){
			$str .= '
			[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
			<br><br>
			';
		}
		*/
			if($product['product_description_instructor'] != ""){
				$str .= $product['product_description_instructor'].'<br><br>';
			} else {
				$str .= $product['product_description_student'].'<br><br>';
			}
			$str .= '
			<span class="bodybold">Product Code: </span> '.$product['product_code'].'<br>
			<span class="bodybold">ISBN: </span> '.$product['product_ISBN'].'<br>
			<span class="bodybold">ISBN 2: </span> '.$product['product_ISBN2'].'<br>
			';
			if($product['product_page_count'] != ""){
				$str .= '
				<span class="bodybold">Pages: </span> '.$product['product_page_count'].'</span><br>
				';
			}
			if($product['product_illustration_count'] != ""){
				$str .= '
				<span class="bodybold">Illustrations: </span> '.$product['product_illustration_count'].'</span><br>
				';
			}
			//-----------------------------------//
			//	4/10/2006 -PC
			//	ADD CODE TO DISPLAY NEW FIELD: PRACTICE QUESTION COUNT
			//-----------------------------------//
			if($product['product_practice_question_count'] != ""){
				$str .= '
				<span class="bodybold">Practice Questions: </span> '.$product['product_practice_question_count'].'</span><br>
				';
			}
			$str .= '
				<span class="bodybold">Price: </span> $'.$product['product_price'].' </span><br>
			';
			if($product['product_available_date'] != ""){
				$str .= '
				<p class="redbolditalic"> This product will ship
				'.$product['product_available_date'].'
				</p>
				';
			}
/*
			if($product['pricing_id']){
			$str .= '
				<span class="bodybold">Discount:</span>
				'.PrintPricingDiscount($product['product_id'],$product['pricing_id']).'
			';
			}
*/
			$str .= '<p><a href="cartadd.php?year='.$year.'&product_id='.$product['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" name="orderoff1" width="100" height="20" onMouseOver="orderoff1.src=\'img/catalog/order_now_on.gif\'" onMouseOut="orderoff1.src=\'img/catalog/order_now_off_yellow.gif\'" border="0" align="absmiddle"></a></p>';
			if(HasRatings($product['product_id'])){
				$str .= '
					<ul><span class="bodynormal">
					<li><a href="ratingview.php?id='.$product['product_id'].'&year='.$year.'">View Ratings</a></li>
					<li><a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></li>
					</ul><br><br><br><br>
				';
			} else {
				$str .= '
					<p class="bodynormal">
					<a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></p>
					</p><br><br><br><br>
				';
			}
			//-----------------------------------//
			//	5/6/2005 ADD CODE FOR NOTES
			//-----------------------------------//
			if($product['product_notes'] != ''){
				$str .= '
				<hr size="1" noshade>
				<span class="bluebolditalic">
				NOTE:
				</span>
				<span class="blue">
				'.DisplayText($product['product_notes']).'
				</span>
				<hr size="1" noshade>
				';
			}
			//-----------------------------------//
			//	4/12/2006 -PC
			//	ADD PRODUCT LINK
			//-----------------------------------//
			if($product['product_link_text']){
			$str .= '
				<br>
				<center>
				<span class="bodybolditalic">
				<a href="'.$product['product_link_url'].'" target="_blank">'.$product['product_link_text'].'</a>
				</span>
				</center>
				<br>
			';
			}
			$str .= '
				</td>
				</tr>
				</table>
			';

//-----------------------------------//
//  9/12/2010 -PC
//  ADD CODE FOR DISPLAYING CUSTOMER COMENTS
//-----------------------------------//
if($product['what_people_say'] != ""){
    $str .= '
    <div id="whatpeoplesay" style="border: 1px solid #000000; width: 300px; margin: 4px auto; padding: 4px; text-align: center;">
<a class="ceebox" href="productComments.php?id='.$product['product_id'].'">Click here to see what customers are saying</a>
    </div>
    ';
}

	$str .= '
		<table width="100%">
		<tr>
		';
		if(($product['product_pdf_toc'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str.= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_pdf_sample'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:500; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_graphic'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:535; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_video'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:570; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="'.$product['product_video'].'">Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="'.$product['product_video'].'">Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		$str .= '
		</tr>
		</table>
	';
		if(($product['product_video'] != "")){
			$str .= '
			<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
				<tr><td class="bodynormal" align="center">
				VIEWING Sample Video FILES requires <a href="http://forms.real.com/netzip/getrde601.html?h=207.188.7.150&f=windows/RealOnePlayerV2GOLD.exe&p=RealOne+Player&oem=dl&tagtype=ie&type=dl" target="_blank">Real Media Player  [ FREE ]</a>
				</td></tr>
			</table>
			';
		}
	return $str;
}

//-----------------------------------//
//	9/30/2004
//	MODIFIED TO REMOVE INSTRUCTOR TEXT PREFERENCE
//	WILL HAVE TO USE A DIFFERENT FUNCTION IN THE
//	INSTRUCTOR VERSION OF THE SITE
//-----------------------------------//
function PrintAllProduct($product,$year){
	$str = '
	<table border="0" cellpadding="4" cellspacing="0" align="center" width="100%">
		<tr valign="top">
			<td>
			'.PrintResizedImage($product['product_image'],'',1).'
			</td>
			<td class="bodynormal">
			';
			//-----------------------------------//
			//	8/29/2006 -PC
			//	ADD DISPLAYING QUIZ LINK IF AVAILABLE
			//-----------------------------------//
			//if($product['product_exam_url']){
			/*
			if($product['category_id'] == 20){
				$str .= '
				[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
				<br>
				';
			}
			*/
			if($product['product_description_student'] != ""){
				$str .= DisplayText($product['product_description_student']).'<br><br>';
			}
/*
			if($product['product_description_instructor'] != ""){
				$str .= DisplayText($product['product_description_instructor']).'<br><br>';
			} else {
				$str .= DisplayText($product['product_description_student']).'<br><br>';
			}
*/
			$str .= '
			<span class="bodybold">Product Code: </span> '.$product['product_code'].'<br>
			<span class="bodybold">ISBN: </span> '.$product['product_ISBN'].'<br>
			<span class="bodybold">ISBN 2: </span> '.$product['product_ISBN2'].'<br>
			';
			if($product['product_page_count'] != ""){
				$str .= '
				<span class="bodybold">Pages: </span> '.$product['product_page_count'].'</span><br>
				';
			}
			if($product['product_illustration_count'] != ""){
				$str .= '
				<span class="bodybold">Illustrations: </span> '.$product['product_illustration_count'].'</span><br>
				';
			}
			if($product['product_video_type'] != ""){
				$str .= '
				<span class="bodyverdanaboldblue">MultiMedia: </span> '.$product['product_video_type'].'</span><br>
				';
			}
			//-----------------------------------//
			//	4/10/2006 -PC
			//	ADD CODE TO DISPLAY NEW FIELD: PRACTICE QUESTION COUNT
			//-----------------------------------//
			if($product['product_practice_question_count'] != ""){
				$str .= '
				<span class="bodybold">Practice Questions: </span> '.$product['product_practice_question_count'].'</span><br>
				';
			}

			$str .= '
				<span class="bodybold">Price: </span> $'.$product['product_price'].' </span><br>
			';
			if($product['product_available_date'] != ""){
				$str .= '
				<p class="redbolditalic"> This product will ship
				'.$product['product_available_date'].'
				</p>
				';
			}
/*
			if($product['pricing_id']){
			$str .= '
				<span class="bodybold">Discount:</span>
				'.PrintPricingDiscount($product['product_id'],$product['pricing_id']).'
			';
			}
*/
			$str .= '<p><a href="cartadd.php?year='.$year.'&product_id='.$product['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" name="orderoff1" width="100" height="20" onMouseOver="orderoff1.src=\'img/catalog/order_now_on.gif\'" onMouseOut="orderoff1.src=\'img/catalog/order_now_off_yellow.gif\'" border="0" align="absmiddle"></a></p>';
			if(HasRatings($product['product_id'])){
				$str .= '
					<ul><span class="bodynormal">
					<li><a href="ratingview.php?id='.$product['product_id'].'&year='.$year.'">View Ratings</a></li>
					<li><a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></li>
					</ul><br><br><br><br>
				';
			} else {
				$str .= '
					<p class="bodynormal">
					<a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></p>
					</p><br><br><br><br>
				';
			}
			//-----------------------------------//
			//	4/12/2006 -PC
			//	ADD PRODUCT LINK
			//-----------------------------------//
			if($product['product_link_text']){
			$str .= '
				<br>
				<center>
				<span class="bodybolditalic">
				<a href="'.$product['product_link_url'].'" target="_blank">'.$product['product_link_text'].'</a>
				</span>
				</center>
				<br>
			';
			}
			//-----------------------------------//
			//	5/6/2005 ADD CODE FOR NOTES
			//-----------------------------------//
			if($product['product_notes'] != ''){
				$str .= '
				<hr size="1" noshade>
				<span class="bluebolditalic">
				NOTE:
				</span>
				<span class="blue">
				'.DisplayText($product['product_notes']).'
				</span>
				<hr size="1" noshade>
				';
			}
			if($product['returnpolicy_id']){
				$str .= '
				<span class="blue">
					'.PrintProductReturnPolicy($product['returnpolicy_id']).'
				</span>
				';
			}
			$str .= '
				</td>
				</tr>
				</table>
			';
	$str .= '
		<table width="100%">
		<tr>
		';
		if(($product['product_pdf_toc'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str.= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_pdf_sample'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:500; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_graphic'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:535; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_video'] != "")){
			if(stristr($product['product_video'],"mov")){
				$target = ' target="blank"';
			}
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:570; z-index:1;">
		<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'"'.$target.'>Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'"'.$target.'>Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		if(($product['dvd_team_list'] != "")){
		////
		$disabledDivs= '
		<div id="toc" style="position:absolute; left:150; top:605; z-index:1;">
		<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1"">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="PopDVDTeam.php?id='.$product['product_id'].'" target="_blank">DVD Team</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</div>
		';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="cebox html" href="PopDVDTeam.php?id='.$product['product_id'].'">DVD Team</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		}
		if(($product['product_audio'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:605; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_audio'].'" target="_blank">Sample Audio</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_audio'].'" target="_blank">Sample Audio</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		$str .= '
		</tr>
		';
		$str .= '
		</table>
		';
		if(($product['product_video'] != "")){
			if(stristr($product['product_video'],"ram")){
					$str .= '
					<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
						<tr><td class="bodynormal" align="center">
						VIEWING Sample Video FILE requires <a href="http://forms.real.com/netzip/getrde601.html?h=207.188.7.150&f=windows/RealOnePlayerV2GOLD.exe&p=RealOne+Player&oem=dl&tagtype=ie&type=dl" target="_blank">Real Media Player  [ FREE ]</a>
						</td></tr>
					</table>
					';
				}
				if(stristr($product['product_video'],"mov")){
					$str .= '
					<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
						<tr><td class="bodynormal" align="center">
						VIEWING Sample Video FILE requires <a href="http://www.apple.com/quicktime/download/" target="_blank">QuickTime Player  [ FREE ]</a>
						</td></tr>
					</table>
					';
				}
				}
	return $str;
}

function PrintLibraryProduct($product,$year){
	$str = '
	<table border="0" cellpadding="4" cellspacing="0" align="center" width="100%">
		<tr valign="top">
			<td>
			<img src="instructor2/'.$product['product_image'].'" width="300" height="280" border="0">
			</td>
			<td class="bodynormal">
			';
			//-----------------------------------//
			//	8/29/2006 -PC
			//	ADD DISPLAYING QUIZ LINK IF AVAILABLE
			//-----------------------------------//
			//if($product['product_exam_url']){
			/*
			if($product['category_id'] == 20){
				$str .= '
				[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
				<br>
				';
			}
			*/
			if($product['product_description_instructor'] != ""){
				$str .= $product['product_description_instructor'].'<br><br>';
			} else {
				$str .= $product['product_description_student'].'<br><br>';
			}
			$str .= '
			<span class="bodybold">Product Code: </span> '.$product['product_code'].'<br>
			<span class="bodybold">ISBN: </span> '.$product['product_ISBN'].'<br>
			<span class="bodybold">ISBN 2: </span> '.$product['product_ISBN2'].'<br>
			';
			if($product['product_page_count'] != ""){
				$str .= '
				<span class="bodybold">Pages: </span> '.$product['product_page_count'].'</span><br>
				';
			}
			if($product['product_illustration_count'] != ""){
				$str .= '
				<span class="bodybold">Illustrations: </span> '.$product['product_illustration_count'].'</span><br>
				';
			}
			//-----------------------------------//
			//	4/10/2006 -PC
			//	ADD CODE TO DISPLAY NEW FIELD: PRACTICE QUESTION COUNT
			//-----------------------------------//
			if($product['product_practice_question_count'] != ""){
				$str .= '
				<span class="bodybold">Practice Questions: </span> '.$product['product_practice_question_count'].'</span><br>
				';
			}
			$str .= '
				<span class="bodybold">Price: </span> $'.$product['product_price'].' </span><br>
			';
			if($product['product_available_date'] != ""){
				$str .= '
				<p class="redbolditalic"> This product will ship
				'.$product['product_available_date'].'
				</p>
				';
			}
			if($product['pricing_id']){
			$str .= '
				<span class="bodybold">Discount:</span>
				'.PrintPricingDiscount($product['product_id'],$product['pricing_id']).'
			';
			}
			$str .= '<p><a href="cartadd.php?year='.$year.'&product_id='.$product['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" name="orderoff1" width="100" height="20" onMouseOver="orderoff1.src=\'img/catalog/order_now_on.gif\'" onMouseOut="orderoff1.src=\'img/catalog/order_now_off_yellow.gif\'" border="0" align="absmiddle"></a></p>';
			if(HasRatings($product['product_id'])){
				$str .= '
					<ul><span class="bodynormal">
					<li><a href="ratingview.php?id='.$product['product_id'].'&year='.$year.'">View Ratings</a></li>
					<li><a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></li>
					</ul><br><br><br><br>
				';
			} else {
				$str .= '
					<p class="bodynormal">
					<a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></p>
					</p><br><br><br><br>
				';
			}
			//-----------------------------------//
			//	4/12/2006 -PC
			//	ADD PRODUCT LINK
			//-----------------------------------//
			if($product['product_link_text']){
			$str .= '
				<br>
				<center>
				<span class="bodybolditalic">
				<a href="'.$product['product_link_url'].'" target="_blank">'.$product['product_link_text'].'</a>
				</span>
				</center>
				<br>
			';
			}
			//-----------------------------------//
			//	5/6/2005 ADD CODE FOR NOTES
			//-----------------------------------//
			if($product['product_notes'] != ''){
				$str .= '
				<hr size="1" noshade>
				<span class="bluebolditalic">
				NOTE:
				</span>
				<span class="blue">
				'.DisplayText($product['product_notes']).'
				</span>
				<hr size="1" noshade>
				';
			}
			$str .= '
				</td>
				</tr>
				</table>
			';

//-----------------------------------//
//  9/12/2010 -PC
//  ADD CODE FOR DISPLAYING CUSTOMER COMENTS
//-----------------------------------//
if($product['what_people_say'] != ""){
    $str .= '
    <div id="whatpeoplesay" style="border: 1px solid #000000; width: 300px; margin: 4px auto; padding: 4px; text-align: center;">
<a class="ceebox" href="productComments.php?id='.$product['product_id'].'">Click here to see what customers are saying</a>
    </div>
    ';
}

	$str .= '
		<table width="100%">
		<tr>
		';
		if(($product['product_pdf_toc'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_pdf_sample'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:500; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_graphic'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:535; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_video'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:570; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'">Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'">Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		$str .= '
		</tr>
		</table>
	';
		if(($product['product_video'] != "")){
			$str .= '
			<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
				<tr><td class="bodynormal" align="center">
				VIEWING Sample Video FILES requires <a href="http://forms.real.com/netzip/getrde601.html?h=207.188.7.150&f=windows/RealOnePlayerV2GOLD.exe&p=RealOne+Player&oem=dl&tagtype=ie&type=dl" target="_blank">Real Media Player  [ FREE ]</a>
				</td></tr>
			</table>
			';
		}
	return $str;
}

function PrintOtherProduct($product,$year){
	$str = '
	<table border="0" cellpadding="4" cellspacing="0" align="center" width="100%">
		<tr valign="top">
			<td>
			<img src="instructor2/'.$product['product_image'].'" width="200" height="250" border="0">
			</td>
			<td class="bodynormal">
			';
			//-----------------------------------//
			//	8/29/2006 -PC
			//	ADD DISPLAYING QUIZ LINK IF AVAILABLE
			//-----------------------------------//
			//if($product['product_exam_url']){
			/*
			if($product['category_id'] == 20){
				$str .= '
				[ <a href="MQE/StudentClassExamListRemote.php?cid=1" target="_blank">Test your knowledge of this subject with our FREE 25 question quiz</a> ]
				<br>
				';
			}
			*/
			if($product['product_description_instructor'] != ""){
				$str .= $product['product_description_instructor'].'<br><br>';
			} else {
				$str .= $product['product_description_student'].'<br><br>';
			}
			$str .= '
			<span class="bodybold">Product Code: </span> '.$product['product_code'].'<br>
			<span class="bodybold">ISBN: </span> '.$product['product_ISBN'].'<br>
			<span class="bodybold">ISBN 2: </span> '.$product['product_ISBN2'].'<br>
			';
			if($product['product_page_count'] != ""){
				$str .= '
				<span class="bodybold">Pages: </span> '.$product['product_page_count'].'</span><br>
				';
			}
			if($product['product_illustration_count'] != ""){
				$str .= '
				<span class="bodybold">Illustrations: </span> '.$product['product_illustration_count'].'</span><br>
				';
			}
			//-----------------------------------//
			//	4/10/2006 -PC
			//	ADD CODE TO DISPLAY NEW FIELD: PRACTICE QUESTION COUNT
			//-----------------------------------//
			if($product['product_practice_question_count'] != ""){
				$str .= '
				<span class="bodybold">Practice Questions: </span> '.$product['product_practice_question_count'].'</span><br>
				';
			}
			$str .= '
				<span class="bodybold">Price: </span> $'.$product['product_price'].' </span><br>
			';
			if($product['product_available_date'] != ""){
				$str .= '
				<p class="redbolditalic"> This product will ship
				'.$product['product_available_date'].'
				</p>
				';
			}
			if($product['pricing_id']){
			$str .= '
				<span class="bodybold">Discount:</span>
				'.PrintPricingDiscount($product['product_id'],$product['pricing_id']).'
			';
			}
			$str .= '<p><a href="cartadd.php?year='.$year.'&product_id='.$product['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" name="orderoff1" width="100" height="20" onMouseOver="orderoff1.src=\'img/catalog/order_now_on.gif\'" onMouseOut="orderoff1.src=\'img/catalog/order_now_off_yellow.gif\'" border="0" align="absmiddle"></a></p>';
			if(HasRatings($product['product_id'])){
				$str .= '
					<ul><span class="bodynormal">
					<li><a href="ratingview.php?id='.$product['product_id'].'&year='.$year.'">View Ratings</a></li>
					<li><a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></li>
					</ul><br><br><br><br>
				';
			} else {
				$str .= '
					<p class="bodynormal">
					<a href="ratingenter.php?id='.$product['product_id'].'&year='.$year.'">Rate This Product</a></p>
					</p><br><br><br><br>
				';
			}
			//-----------------------------------//
			//	4/12/2006 -PC
			//	ADD PRODUCT LINK
			//-----------------------------------//
			if($product['product_link_text']){
			$str .= '
				<br>
				<center>
				<span class="bodybolditalic">
				<a href="'.$product['product_link_url'].'" target="_blank">'.$product['product_link_text'].'</a>
				</span>
				</center>
				<br>
			';
			}
			$str .= '
				</td>
				</tr>
				</table>
			';

//-----------------------------------//
//  9/12/2010 -PC
//  ADD CODE FOR DISPLAYING CUSTOMER COMENTS
//-----------------------------------//
if($product['what_people_say'] != ""){
    $str .= '
    <div id="whatpeoplesay" style="border: 1px solid #000000; width: 300px; margin: 4px auto; padding: 4px; text-align: center;">
<a class="ceebox" href="productComments.php?id='.$product['product_id'].'">Click here to see what customers are saying</a>
    </div>
    ';
}


	$str .= '
		<table width="100%">
		<tr>
		';
		if(($product['product_pdf_toc'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_toc'].'" target="_blank">Table of Contents</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_pdf_sample'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_pdf_sample'].'" target="_blank">Sample Pages</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_graphic'] != "")){
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a class="ceebox" href="instructor2/'.$product['product_graphic'].'">Sample Graphic</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		if(($product['product_video'] != "")){
			if(stristr($product['product_video'],"mov")){
				$target = ' target="blank"';
			}
		////
		$disabledDivs= '<div id="toc" style="position:absolute; left:150; top:465; z-index:1;">			<table width="140" border="0" cellpadding="0" bgcolor="#43486F" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" background="img/common/whitebg.gif">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#43486F" width="4%"><img src="img/common/blackbg.gif" width="5" height="19"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'"'.$target.'>Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table></div>';
		////
			$str .= '
			<td align="center">
			<table width="140" border="0" cellpadding="0" bgcolor="#000000" cellspacing="1">
			<tr>
			<td width="140">
				<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
				<tr>
				<td class="bodynormal" align="center" nowrap height="20" bgcolor="#000000" width="4%"><img src="img/common/shim.gif" width="5" height="8"></td>
				<td class="bodynormal" align="center" nowrap height="20" width="96%"><a href="instructor2/'.$product['product_video'].'"'.$target.'>Sample Video</a>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</td>
			';
		} else {
			//$str .= '<td>&nbsp;</td>';
		}
		$str .= '
		</tr>
		</table>
	';
	if(($product['product_video'] != "")){
		if(stristr($product['product_video'],"ram")){
			$str .= '
			<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
				<tr><td class="bodynormal" align="center">
				VIEWING Sample Video FILE requires <a href="http://forms.real.com/netzip/getrde601.html?h=207.188.7.150&f=windows/RealOnePlayerV2GOLD.exe&p=RealOne+Player&oem=dl&tagtype=ie&type=dl" target="_blank">Real Media Player  [ FREE ]</a>
				</td></tr>
			</table>
			';
		}
		if(stristr($product['product_video'],"mov")){
			$str .= '
			<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
				<tr><td class="bodynormal" align="center">
				VIEWING Sample Video FILE requires <a href="http://www.apple.com/quicktime/download/" target="_blank">QuickTime Player  [ FREE ]</a>
				</td></tr>
			</table>
			';
		}
	}
	return $str;
}

function HasDiscount($val){
	if($val == 0){
		return "No";
	} else {
		return "Yes";
	}
}

function PrintDiscountYesNo($pricing_id){
	if($pricing_id){
		return "Yes";
	} else {
		return "No";
	}
}

// LAME BUT EFFICIENT BYPASS OF TABLE COLUMN ENUM OPTION SEEK ... CLEAN UP LATER
function PrintProductTypeSelect($selected){
	switch($selected){
	case Book:
		$str = "<select name='product_type'>\n";
		$str .= "<option value='All'>All</option>\n";
		$str .= "<option value='Book' selected>Book</option>\n";
		$str .= "<option value='Course'>Course</option>\n";
		$str .= "<option value='Library'>Library</option>\n";
		$str .= "<option value='Other'>Other</option>\n";
		$str .= "</select>\n";
		break;
	case Course:
		$str = "<select name='product_type'>\n";
		$str .= "<option value='All'>All</option>\n";
		$str .= "<option value='Book'>Book</option>\n";
		$str .= "<option value='Course' selected>Course</option>\n";
		$str .= "<option value='Library'>Library</option>\n";
		$str .= "<option value='Other'>Other</option>\n";
		$str .= "</select>\n";
		break;
	case Library:
		$str = "<select name='product_type'>\n";
		$str .= "<option value='All'>All</option>\n";
		$str .= "<option value='Book'>Book</option>\n";
		$str .= "<option value='Course'>Course</option>\n";
		$str .= "<option value='Library' selected>Library</option>\n";
		$str .= "<option value='Other'>Other</option>\n";
		$str .= "</select>\n";
		break;
	case Other:
		$str = "<select name='product_type'>\n";
		$str .= "<option value='All'>All</option>\n";
		$str .= "<option value='Book'>Book</option>\n";
		$str .= "<option value='Course'>Course</option>\n";
		$str .= "<option value='Library'>Library</option>\n";
		$str .= "<option value='Other' selected>Other</option>\n";
		$str .= "</select>\n";
		break;
	default:
		$str = "<select name='product_type'>\n";
		$str .= "<option value='All' selected>All</option>\n";
		$str .= "<option value='Book'>Book</option>\n";
		$str .= "<option value='Course'>Course</option>\n";
		$str .= "<option value='Library'>Library</option>\n";
		$str .= "<option value='Other'>Other</option>\n";
		$str .= "</select>\n";
		break;
	}
	return $str;
}

function  PrintProductCategoryClearanceList(){
	$sql="SELECT product.*, category.*
FROM
 product
 INNER JOIN category ON (product.category_id=category.category_id)
			where product.clearanceItem=1 and product_sort > 0
			order by category_year DESC
			";
	//die($sql);
	$resID = db_query($sql);

	if(!$resID){
		return "<br><center><span class='bodynormal'>There are no books for this category.</span></center>";
	}
	$str = '<table width="100%" cellpadding="4" cellspacing="0">';
	$str .= '
	<tr>
	<td class="bodybold"  bgcolor="#EFEFEF">
	Title
	</td>
	<td bgcolor="#EFEFEF">
	&nbsp;
	</td>
	<td class="bodybold" align="center" bgcolor="#EFEFEF">
	Price
	</td>
	<td align="center" class="bodybold" bgcolor="#EFEFEF">D e s c r i p t i o n</td>
	</tr>
	';
	$count = 0;
	while($row = db_fetch_array($resID)){
		$count++;
		$str .= '
		<tr valign="top">
		<td class="bodynormal">
		<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">'.PrintResizedImage($row['product_image'],'-',"2").'</a>
		</td>
		<td class="bodynormal">
		<a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">['.$row['product_title'].'</a><br><span style="font-size: 11px; font-weight: bold">['.$row['product_code'].']</span><br><br><a href="cartadd.php?year='.$row['category_year'].'&product_id='.$row['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a><br><br>
		</td>
		<td class="bodynormal" nowrap>
		&nbsp;<span style="color:red;text-decoration:line-through"><span style="color:black">$'.$row['originalPrice'].'</span></span><br>
		&nbsp;$'.$row['product_price'].'
		</td>
		<td class="bodynormal">
		';
		$str .= strip_tags(substr($row['product_description_student'],0,250)).'...
		<span style="font-size: 11px; background-color: #efefef; font-weight: bold; padding: 2px 2px;"><a href="productitem.php?id='.$row['product_id'].'&year='.$row['category_year'].'&from='.$from.'&title='.urlencode($title).'&searchtext='.urlencode($searchtext).'&product_type='.$row['product_type'].'&category_from='.$row['product_type'].'">More Info</a></span>
		</td>
		</tr>
		';
	}
	$str .= '</table>';
	//echo $count;
	return $str;
}
/* END product.inc */

?>