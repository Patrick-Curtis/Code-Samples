<?
// connect to db etc.
//-----------------------------------//
//	DETECT SERVER YOU'RE ON
//-----------------------------------//
if(stristr($_SERVER['HTTP_HOST'],"localhost")){
	$main_hostname = "localhost";
	$db_name       = "holtinstructor";
	$db_hostname   = "localhost";
	$db_username   = "root";
	$db_password   = "";
	$db            = "holtinstructor";
	function db_start(){

	    global $db;
	    global $db_hostname;
	    global $db_username;
	    global $db_name;
	    $db = mysql_connect($db_hostname, $db_username) or die("Can't connect to $db_hostname!");
	    mysql_select_db($db_name,$db) or die("Can't connect to $db_name!");

	} // E N D   d b _ s t a r t ( )
} else {
	$main_hostname = "localhost";
	$db_name       = "holtinstructor";
	$db_hostname   = "localhost";
	$db_username   = "holtinstructor";
	$db_password   = "xxxxxxxxxxxxxx";
	$db            = "holtinstructor";
	function db_start(){

	    global $db;
	    global $db_hostname;
	    global $db_username;
	    global $db_password;
	    global $db_name;

	    $db = mysql_connect($db_hostname, $db_username, $db_password) or die("Down for maintenance.");
	    mysql_select_db($db_name,$db) or die("Down for maintenance.");

	} // E N D   d b _ s t a r t ( )
}

// START DB EVERYTIME YOU INCLUDE THIS FILE
db_start();

$last__id = "";

function db_fetch_array($result) {

	return mysql_fetch_array($result);
}

function db_fetch_row($result) {

	return mysql_fetch_row($result);
}

function db_num_rows($result) {

    if($result){
        return mysql_num_rows($result);
    }
    return 0;
}

//-----------------------------------//
//	6/29/2005
//	ADDED CODE TO RECORD AN ERROR LOG
//-----------------------------------//
function db_query($query)
{
	global $db_name;
	//-----------------------------------//
	//	6/29/2005
	//	mysql_db_query() IS DEPRECATED IN SOME VERSIONS OF PHP
	//	FROM VERSION PHP 4.0.6. AND ONWARD
	//-----------------------------------//
	//$result = mysql_db_query($db_name,$query);
	$result = mysql_query($query);
	if (!$result){
		//-----------------------------------//
		//	SAVE TIME AND ERROR INFO TO LOG
		//  NEED TO ADD FILE TRUNCATING FUNCTON HERE
		//-----------------------------------//
		$errorinfo = date("Ymd g:i:sa T")." | MySql Error No: ".mysql_errno()." | MySql Error Code: ".mysql_error()."\n";
		$fp = fopen("cartlogs/mysql-errors.txt","a+");
		fwrite($fp,$errorinfo);
		fclose($fp);
		return false;
    }
//	echo "<br>". $query ."<br>";   //  DEBUG
	return $result;
}

function db_insert_list($table, $data_list) {
    $query = "INSERT INTO $table (";
    while (list($column, $value) = each($data_list))
    {
        $columns[] = $column;
        $values[]  = "'" .mysql_real_escape_string($value). "'";
    }
    $query = $query
       . implode($columns, ", ")
       . ") VALUES ("
       . implode($values, ", ")
       . ")";
//    echo "Your query is: " .$query. "<br>";   //  DEBUG
	$ret = db_query($query);
	if (!$ret):
		//echo mysql_errno().": ".mysql_error()."<BR>"; // NEED BETTER ERROR HANDLING HERE
		//-----------------------------------//
		//	6/16/2005 ADD WRITING ERROR TO LOG FILE
		//	TO DEBUG PROBLEMS INSERTING NEW BUYER INFORMATION
		//-----------------------------------//
		global $HTTP_SESSION_VARS;
		$fp = fopen("cartlogs/mysql-errors.txt","a+");
		$entry = date("Ymd g:i:sa T")." | CartID: ".$HTTP_SESSION_VARS['cart_id']." | DATABASE GENERAL INSERTION ERROR: mysql_errno()\n";
		fwrite($fp,$entry);
		fclose($fp);
		return false;
	endif;
	return $last__id = mysql_insert_id();
} // E N D   d b _ i n s e r t _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ e n d _ c o u n t )

function db_replace_list($table, $data_list) {
    $query = "REPLACE INTO $table (";
    while (list($column, $value) = each($data_list))
    {
        $columns[] = $column;
        $values[]  = "'" .mysql_real_escape_string($value). "'";
    }
    $query = $query
       . implode($columns, ", ")
       . ") VALUES ("
       . implode($values, ", ")
       . ")";
//    echo "Your query is: " .$query. "<br>";   //  DEBUG
	$ret = db_query($query);
	if (!$ret):
		//echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here
		return false;
	endif;
	return $last__id = mysql_insert_id();
} // E N D   d b _ i n s e r t _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ e n d _ c o u n t )

function db_update_list_disabled_prePHP5($table, $data_list, $id_name, $id) {
	$end_count = sizeof($data_list);
 	$query = "UPDATE $table SET ";
	$key = array_keys($data_list);
	$val = array_values($data_list);
	for ($i = 1; $i < $end_count; $i++)
		{
		if($i == $end_count-1)
			{
            $query = $query. $key[$i]. "='" .mysql_real_escape_string($val[$i]). "'";
			}
		else
			{
			$query = $query. $key[$i]. "='" .mysql_real_escape_string($val[$i]). "', ";
			}
		}

	$query = $query. " WHERE $id_name='$id'";
//  	echo "QUERY RESULT IN DB FILE IS $query<br>";   //  DEBUG
	$ret = mysql_query($query);
	if (!$ret):
		//echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here
		return false;
	endif;
	return $ret;
}

function db_update_list($table, $data_list, $id_name, $id) {
       $end_count = sizeof($data_list);
       $query = "UPDATE `$table` SET ";
       $key = array_keys($data_list);
       $val = array_values($data_list);
       //$end_count = sizeof($key);
       for ($i = 1; $i < $end_count; $i++){
               if(($i +1) == $end_count){
           $query = $query. $key[$i]." = '" .mysql_real_escape_string($val[$i]). "'\n";
               }else{
                       $query = $query. $key[$i]." = '" .mysql_real_escape_string($val[$i]). "', \n";
               }
       //echo "\$key[$i] --> ".$key[$i]."<br>";    //    DEBUG
       }
       $query = $query. "\n WHERE $id_name = $id";
       //echo "<p>UPDATE QUERY RESULT IS <br><pre>$query</pre></p>";   //  DEBUG
       $ret = mysql_query($query);
       if (!$ret):
               echo mysql_errno().": ".mysql_error()."<BR>"; // NEED BETTER ERROR HANDLING HERE
               return false;
       endif;
       return $ret;
} // E N D   d b _ u p d a t e _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ i d _ n a m e ,   $ i d )

?>		