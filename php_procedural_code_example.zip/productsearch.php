<?

//-----------------------------------//
//	FINDS ANDS PRINTS PRODUCT SEARCHES
//-----------------------------------//

function SearchProduct($text,$product_type,$year){
	$aText = explode(" ",$text);
	$max = sizeof($aText);
	$words = "";
	//-----------------------------------//
	//	11/11/2005
	//	ADD ISBN LOOKUP TO QUERY
	//	product_ISBN in holtinstructor table
	//-----------------------------------//
	for($i = 0; $i < $max; $i++){
		$words .= "
		AND
		(
		product_title LIKE '%".$aText[$i]."%'
		OR product.product_description_student LIKE '%".$aText[$i]."%'
		OR product.product_code LIKE '%".$aText[$i]."%'
		OR product.product_ISBN LIKE '%".$aText[$i]."%'
		)
		";
	}
	$sql = "
	SELECT DISTINCT(product.product_id) AS product_id,
	product.product_title AS product_title,
	product.product_type AS product_type,
	product.product_image AS product_image,
	product.product_ISBN AS product_ISBN,
	product.product_description_student AS product_description_student,
	category.category_title AS category_title,
	category.category_year AS category_year
	FROM product,category
	WHERE  product_sort > 0 AND product_disabled = 0 AND
	";
	if($year != "All"){
		$sql .= "
		category.category_year = '$year'
		AND
		";
	}
	$sql .= "
	product.category_id = category.category_id
	";
	if($product_type != 'All'){
		$sql .= "
		AND
		product.product_type = '$product_type'
		";
	}
	$sql .= $words;
/*
	$sql .= "
	(product_title LIKE '%$text%'
	OR product.product_description_student LIKE '%$text%'
	OR product.product_code LIKE '%$text%'
	)
	";
*/
	$sql .= "
	GROUP BY product.product_id,category.category_id
	ORDER BY product.product_type,category.category_year,category.category_title,product.product_title
	";
//	echo $sql."<br>";
//	exit;
	$resID = db_query($sql);
	if(db_num_rows($resID)){
		return $resID;
	}
	return false;
}

function PrintProductSearchResult($text,$product_type,$year){
	$resID = SearchProduct($text,$product_type,$year);
	if($resID){
	$str ='
	<table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#000000">
	<tr>
	<td align="center" height="25" class="yellow12pxbold">Search Results for \''.$text.'\'
	</td>
	</tr>
	<tr>
	<td>
	<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#FFFFFF">
	<tr valign="top">
	<td colspan="4" bgcolor="#efefef" class="bodybold" align="center">
	Click on image or title to view
	</td>
	</td>
	</tr>
	';
	while($r = db_fetch_array($resID)){
		$img = "instructor2/".$r['product_image'];
		$str .= '
		<tr valign="top">
		<td>
		'.PrintResizedImage($r['product_image'],"-",2).'
		</td>
		<td>
		<a href="productitem.php?id='.$r['product_id'].'&year='.$year.'&from=Search&title='.$r['category_title'].'&product_type='.$r['product_type'].'&searchtext='.urlencode($_REQUEST['searchtext']).'">'.$r['product_title'].'</a><br><br><a href="cartadd.php?product_id='.$r['product_id'].'"><img src="img/catalog/order_now_off_yellow.gif" border="0"></a>
		&nbsp;
		</td>
		<td class="bodygreenbold">
		'.$r['product_type'].'&nbsp;
		</td>
		<td>
		'.substr($r['product_description_student'],0,300).' ... &nbsp;
		'.PrintViewCategoryLink($r,$text).'
		</td>
		</tr>
		<tr valign="top">
		<td colspan="4">
		<a href="#top"><img src="img/nav/topoff.gif" name="image1" width="55" height="20" border="0" alt="Back to top"  onMouseOver="this.src=\'img/nav/topon.gif\'" onMouseOut="this.src=\'img/nav/topoff.gif\'"></a>
		<hr size="1" noshade>
		</td>
		</tr>
		';
	}
	$str .= '
	</table>
	</td>
	</tr>
	</table>
	';
	return $str;
	} else {
		print '
		<hr size="1" noshade>
		<p align="center" class="bodybold">
		Nothing found for "'.$text.'"
		</p>
		<p align="center" class="bodynormal">
		Try using fewer words or a different year or product type above
		</p>
		<hr size="1" noshade>
		';
	}
}
function PrintSearchYearSelect($year){
	$str ='<select name="year">';
	switch($year){
	case All :
		$str .='<option value="All" selected>All</option>';
		$str .='<option value="2011">2011</option>';
		$str .='<option value="2008">2008</option>';
		$str .='<option value="2005">2005</option>';
		$str .='<option value="2002">2002</option>';
	break;
	case 2011 :
		$str .='<option value="All">All</option>';
		$str .='<option value="2011" selected>2011</option>';
		$str .='<option value="2008">2008</option>';
		$str .='<option value="2005">2005</option>';
		$str .='<option value="2002">2002</option>';
	break;
	case 2008 :
		$str .='<option value="All">All</option>';
		$str .='<option value="2011">2011</option>';
		$str .='<option value="2008" selected>2008</option>';
		$str .='<option value="2005">2005</option>';
		$str .='<option value="2002">2002</option>';
	break;
	case 2005 :
		$str .='<option value="All">All</option>';
		$str .='<option value="2011">2011</option>';
		$str .='<option value="2008">2008</option>';
		$str .='<option value="2005" selected>2005</option>';
		$str .='<option value="2002">2002</option>';
	break;
	case 2002 :
		$str .='<option value="All">All</option>';
		$str .='<option value="2011">2011</option>';
		$str .='<option value="2008">2008</option>';
		$str .='<option value="2005">2005</option>';
		$str .='<option value="2002" selected>2002</option>';
	break;
	default:
		$str .='<option value="All">All</option>';
		$str .='<option value="2011">2011</option>';
		$str .='<option value="2008">2008</option>';
		$str .='<option value="2005">2005</option>';
		$str .='<option value="2002">2002</option>';
	}
	$str .='</select>';
	return $str;
}

function PrintViewCategoryLink($r,$text){
	$str = '';
	switch($r['product_type']){
	case Book:
		$str .='
		<p class="bodynormal">
		<a href="bookcategory.php?title='.urlencode($r['category_title']).'&year='.$r['category_year'].'&from=Search&product_type='.$r['product_type'].'&searchtext='.$text.'">View all '.$r['category_year'].'
		'.$r['category_title'].'
		books</a>
		</p>
		';
	break;
	case Course:
		$str .='
		<p class="bodynormal">
		<a href="coursecategory.php?title='.urlencode($r['category_title']).'&year='.$r['category_year'].'&from=Search&product_type='.$r['product_type'].'&searchtext='.$text.'">View all '.$r['category_year'].'
		'.$r['category_title'].'
		courses</a>
		</p>
		';
	break;
	case Library:
		$str .='
		<p class="bodynormal">
		<a href="librarycategory.php?title='.urlencode($r['category_title']).'&year='.$r['category_year'].'&from=Search&product_type='.$r['product_type'].'&searchtext='.$text.'">View all '.$r['category_year'].'
		'.$r['category_title'].'
		libraries</a>
		</p>
		';
	break;
	case Other:
		$str .='
		<p class="bodynormal">
		<a href="othercategory.php?title='.urlencode($r['category_title']).'&year='.$r['category_year'].'&from=Search&product_type='.$r['product_type'].'&searchtext='.$text.'">View all '.$r['category_year'].'
		'.$r['category_title'].'
		other</a>
		</p>
		';
	break;
	default:
	}
	return $str;
}

//-----------------------------------//
//	2/20/2006 -PC
//	PARSES GOOGLE REFERER GET STRING
//-----------------------------------//
//	Example: http://www.google.com/search?hl=en&lr=&q=mikeholt.com+freegeneral&btnG=Search
function ParseGoogleReferer($get_str){
	$tmpstr = '';
	$aTmp1 = explode("q=", $get_str);	//	RESULT $aTmp1[1] mikeholt.com+freegeneral&btnG=Search
	$aTmp2 = explode("&", $aTmp1[1]);	//	RESULT $aTmp2[0] mikeholt.com+freegeneral AND $aTmp2[1] btnG=Search
	$aTmp3 = explode("+", $aTmp2[0]);	//	RESULT (THIS CAN VARY) $aTmp3[0] mikeholt.com AND $aTmp3[1] freegeneral AND $aTmp3[2]... etc.
	//-----------------------------------//
	//	IF MORE THAN ONE ELEMENT IN $aTmp3
	//	PUT THE SEARCH WORDS TOGETHER
	//-----------------------------------//
	$max = sizeof($aTmp3);
	if($max > 1){
		for($i = 0; $i < $max; $i++){
			$tmpstr .= $aTmp3[$i].' ';
		}
		//-----------------------------------//
		//	REMOVE "mikeholt.com" AND BEGINNING
		//	AND ENDING SPACES FROM FINAL ENTRY
		//-----------------------------------//
		$outstr = strtolower(trim(str_replace("MIKEHOLT.COM", "", strtoupper($tmpstr))));
	} elseif($aTmp3[0]) {
		$outstr = trim($aTmp3[0]);
	} else {
		$outstr = '';
	}
	return $outstr;
}
?>