Files demonstrate a procedural approach to:
1. MySQL DB COnnection
2. Table wrapping/protection

Using these functions allows you to do a couple of things:
1. "Throw" $_POST content at a table
2. Protect your DB from injection attacks

Threw in a couple of miscellaneous functions as well