<?
//-----------------------------------//
// RANDOM NUMBER GENERATORS
//-----------------------------------//
function RandomNumber($start){
	// seed with microseconds
	mt_srand(make_seed());
	$randnum = mt_rand($start,999999);
	$num = substr((string)$randnum, $start, "3");
	return sprintf("%03d",$num);
}

//-----------------------------------//
//	SEED MT_RAND WITH MICROSECONDS
//-----------------------------------//
function make_seed() {
    list($usec,$sec) = explode(" ", microtime());
    return ((float)$sec+(float)$usec) * 100000;
}
// END RANDOM.INC
?>