-- phpMyAdmin SQL Dump
-- version 3.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 12, 2011 at 12:03 AM
-- Server version: 5.0.51
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `holtinstructor`
--

-- --------------------------------------------------------

--
-- Table structure for table `affiliate`
--

CREATE TABLE IF NOT EXISTS `affiliate` (
  `affiliate_id` int(20) unsigned NOT NULL auto_increment,
  `affiliate_account_number` varchar(255) default NULL,
  `affiliate_name` varchar(255) default NULL,
  `affiliate_title` varchar(255) default NULL,
  `affiliate_company_name` varchar(255) default NULL,
  `affiliate_address` varchar(255) default NULL,
  `affiliate_city` varchar(255) default NULL,
  `affiliate_state` varchar(255) default NULL,
  `affiliate_country` varchar(255) default NULL,
  `affiliate_zip` varchar(255) default NULL,
  `affiliate_phone` varchar(255) default NULL,
  `affiliate_fax` varchar(255) default NULL,
  `affiliate_email` varchar(255) default NULL,
  `affiliate_url` varchar(255) default NULL,
  `affiliate_ssn` varchar(255) default NULL,
  `affiliate_payment_preference` enum('Cash','Credit') NOT NULL default 'Cash',
  `affiliate_status` enum('Active','Inactive') NOT NULL default 'Inactive',
  `affiliate_modified` varchar(255) default NULL,
  PRIMARY KEY  (`affiliate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=242 ;

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE IF NOT EXISTS `buyer` (
  `buyer_id` int(20) unsigned NOT NULL auto_increment,
  `buyer_customer_number` varchar(255) default NULL,
  `buyer_first_name` varchar(255) default NULL,
  `buyer_middle_initial` varchar(255) default NULL,
  `buyer_last_name` varchar(255) default NULL,
  `buyer_company_name` varchar(255) default NULL,
  `buyer_company_title` varchar(255) default NULL,
  `buyer_address_1` varchar(255) default NULL,
  `buyer_address_2` varchar(255) default NULL,
  `buyer_city` varchar(255) default NULL,
  `buyer_state_id` tinyint(2) unsigned default NULL,
  `buyer_country_id` tinyint(3) unsigned default NULL,
  `buyer_zip` varchar(255) default NULL,
  `buyer_phone_day` varchar(255) default NULL,
  `buyer_phone_eve` varchar(255) default NULL,
  `buyer_phone_fax` varchar(255) default NULL,
  `buyer_email` varchar(255) default NULL,
  `buyer_modified` varchar(255) default NULL,
  `buyer_password` varchar(50) default NULL,
  `bDay` int(2) default NULL,
  `bDayMonth` int(2) default NULL,
  PRIMARY KEY  (`buyer_id`),
  KEY `id_index` (`buyer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39258 ;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `cart_id` varchar(255) default NULL,
  `Modified` varchar(255) default NULL,
  `lastPage` text,
  `lastUpdated` timestamp NULL default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cartitem`
--

CREATE TABLE IF NOT EXISTS `cartitem` (
  `cartitem_id` int(20) unsigned NOT NULL auto_increment,
  `cart_id` varchar(255) default NULL,
  `product_id` mediumint(8) unsigned default NULL,
  `product_qty` mediumint(6) unsigned default NULL,
  `desires_CEU_credit` varchar(255) default NULL,
  `licenseFirstName1` varchar(255) default NULL,
  `licenseMI1` char(1) default NULL,
  `licenseLastName1` varchar(255) default NULL,
  `licenseState1` varchar(255) default NULL,
  `licenseNo1` varchar(255) default NULL,
  `licenseFirstName2` varchar(255) default NULL,
  `licenseMI2` char(1) default NULL,
  `licenseLastName2` varchar(255) default NULL,
  `licenseState2` varchar(255) default NULL,
  `licenseNo2` varchar(255) default NULL,
  `licenseFirstName3` varchar(255) default NULL,
  `licenseMI3` char(1) default NULL,
  `licenseLastName3` varchar(255) default NULL,
  `licenseState3` varchar(255) default NULL,
  `licenseNo3` varchar(255) default NULL,
  `licenseFirstName4` varchar(255) default NULL,
  `licenseMI4` char(1) default NULL,
  `licenseLastName4` varchar(255) default NULL,
  `licenseState4` varchar(255) default NULL,
  `licenseNo4` varchar(255) default NULL,
  `licenseFirstName5` varchar(255) default NULL,
  `licenseMI5` char(1) default NULL,
  `licenseLastName5` varchar(255) default NULL,
  `licenseState5` varchar(255) default NULL,
  `licenseNo5` varchar(255) default NULL,
  `product_shipping` decimal(8,2) NOT NULL default '0.00',
  PRIMARY KEY  (`cartitem_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=632494 ;

-- --------------------------------------------------------

--
-- Table structure for table `cartlogin`
--

CREATE TABLE IF NOT EXISTS `cartlogin` (
  `cartlogin_id` int(20) unsigned NOT NULL auto_increment,
  `buyer_id` int(20) unsigned default NULL,
  `cartlogin` varchar(255) default NULL,
  `cartpassword` varchar(255) default NULL,
  `cartloginmodified` varchar(255) default NULL,
  PRIMARY KEY  (`cartlogin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4136 ;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` mediumint(8) unsigned NOT NULL auto_increment,
  `category_title` varchar(255) default NULL,
  `category_year` varchar(255) default NULL,
  `category_text` text,
  `category_sort` decimal(4,1) default NULL,
  PRIMARY KEY  (`category_id`),
  UNIQUE KEY `category_id` (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Product Category List' AUTO_INCREMENT=54 ;

-- --------------------------------------------------------

--
-- Table structure for table `ceu`
--

CREATE TABLE IF NOT EXISTS `ceu` (
  `ceuID` int(11) NOT NULL auto_increment,
  `productCode` varchar(255) default NULL,
  `state` varchar(255) NOT NULL default '',
  `code` varchar(255) NOT NULL default '',
  `hours` int(2) NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ceuID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `country_id` tinyint(3) unsigned NOT NULL auto_increment,
  `country_code` varchar(255) NOT NULL default '',
  `country_name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`country_id`),
  UNIQUE KEY `ID` (`country_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=242 ;

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE IF NOT EXISTS `discount` (
  `discount_id` int(20) unsigned NOT NULL auto_increment,
  `discount_code` varchar(255) default NULL,
  `discount_begin` varchar(255) default NULL,
  `discount_end` varchar(255) default NULL,
  `discount_amount_type` enum('Percent','Dollar','Quantity') NOT NULL default 'Percent',
  `discount_amount_num` varchar(255) default NULL,
  `discount_target_year` varchar(255) default NULL,
  `discount_target_category_id` varchar(255) default NULL,
  `discount_target_product_code` varchar(255) default NULL,
  `discount_text` varchar(255) default NULL,
  `discount_modified` varchar(255) default NULL,
  `discount_free_ship` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`discount_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=444 ;

-- --------------------------------------------------------

--
-- Table structure for table `dvd_team`
--

CREATE TABLE IF NOT EXISTS `dvd_team` (
  `dvd_team_id` int(20) unsigned NOT NULL auto_increment,
  `dvd_team_firstname` varchar(255) default NULL,
  `dvd_team_lastname` varchar(255) default NULL,
  `dvd_team_short_description` text NOT NULL,
  `dvd_team_long_description` text NOT NULL,
  `dvd_team_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`dvd_team_id`),
  KEY `dvd_team_image` (`dvd_team_image`),
  KEY `dvd_team_firstname` (`dvd_team_firstname`),
  KEY `dvd_team_lastname` (`dvd_team_lastname`),
  FULLTEXT KEY `dvd_team_short_description` (`dvd_team_short_description`,`dvd_team_long_description`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

-- --------------------------------------------------------

--
-- Table structure for table `licenses`
--

CREATE TABLE IF NOT EXISTS `licenses` (
  `licenseID` int(20) NOT NULL auto_increment,
  `receipt_id` int(20) NOT NULL default '0',
  `licenseNo` varchar(255) NOT NULL default '',
  `licenseState` char(2) NOT NULL default '',
  `licenseFirstName` varchar(255) NOT NULL default '',
  `licenseLastName` varchar(255) NOT NULL default '',
  `licenseMI` char(1) NOT NULL default '',
  PRIMARY KEY  (`licenseID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(20) unsigned NOT NULL auto_increment,
  `login_email` varchar(255) default NULL,
  `login_zipcode` varchar(255) default NULL,
  `login_modified` varchar(255) default NULL,
  PRIMARY KEY  (`login_id`),
  UNIQUE KEY `login_id` (`login_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='login used for session management' AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `nodiscount`
--

CREATE TABLE IF NOT EXISTS `nodiscount` (
  `nodiscount_id` tinyint(3) unsigned NOT NULL auto_increment,
  `nodiscount_code` varchar(255) default NULL,
  `nodiscount_begin` varchar(255) default NULL,
  `nodiscount_end` varchar(255) default NULL,
  `nodiscount_always` enum('Yes','No') NOT NULL default 'No',
  `nodiscount_modified` varchar(255) default NULL,
  PRIMARY KEY  (`nodiscount_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=195 ;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `paymentID` int(11) NOT NULL auto_increment,
  `orderNo` int(11) NOT NULL default '0',
  `amount` float NOT NULL default '0',
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `authCode` text,
  `approvalNo` text,
  PRIMARY KEY  (`paymentID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pricing`
--

CREATE TABLE IF NOT EXISTS `pricing` (
  `pricing_id` mediumint(8) unsigned NOT NULL auto_increment,
  `pricing_break_1` varchar(255) default NULL,
  `pricing_break_2` varchar(255) default NULL,
  `pricing_break_3` varchar(255) default NULL,
  `pricing_break_4` varchar(255) default NULL,
  `pricing_break_5` varchar(255) default NULL,
  `pricing_break_6` varchar(255) default NULL,
  `pricing_break_7` varchar(255) default NULL,
  `pricing_discount_multiplier` tinyint(2) unsigned NOT NULL default '0',
  PRIMARY KEY  (`pricing_id`),
  UNIQUE KEY `pricing_id` (`pricing_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Pricing Information for Products' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `product_id` mediumint(8) unsigned NOT NULL auto_increment,
  `category_id` mediumint(8) unsigned NOT NULL default '0',
  `category2_id` mediumint(8) default NULL,
  `pricing_id` mediumint(8) default NULL,
  `returnpolicy_id` tinyint(3) unsigned default NULL,
  `product_ceu_credit` enum('Yes','No') NOT NULL default 'No',
  `product_image` varchar(255) default NULL,
  `product_title` varchar(255) default NULL,
  `product_code` varchar(255) default NULL,
  `product_price` decimal(8,2) NOT NULL default '0.00',
  `product_taxable` enum('Yes','No') NOT NULL default 'Yes',
  `product_weight` decimal(5,1) NOT NULL default '0.0',
  `product_type` varchar(255) default '',
  `product_ISBN` varchar(255) default NULL,
  `product_page_count` varchar(255) default NULL,
  `product_illustration_count` varchar(255) default NULL,
  `product_video_type` varchar(255) default NULL,
  `product_description_student` text,
  `product_description_instructor` text,
  `product_available_date` varchar(255) default NULL,
  `product_pdf_toc` varchar(255) default NULL,
  `product_pdf_sample` varchar(255) default NULL,
  `product_graphic` varchar(255) default NULL,
  `product_graphic_border` text,
  `product_video` varchar(255) default NULL,
  `product_audio` varchar(255) default NULL,
  `product_modified` varchar(255) default NULL,
  `product_notes` text,
  `product_sort` float default NULL,
  `product_practice_question_count` varchar(255) default NULL,
  `product_link_text` varchar(255) default NULL,
  `product_link_url` varchar(255) default NULL,
  `product_exam_url` varchar(255) default NULL,
  `no_code_year` tinyint(1) NOT NULL default '1',
  `electronic_product` tinyint(1) NOT NULL default '0',
  `download_link` varchar(255) default NULL,
  `online_course` tinyint(1) NOT NULL default '0',
  `online_course_id` varchar(255) default NULL,
  `seminar` tinyint(1) NOT NULL default '0',
  `product_ISBN2` varchar(255) NOT NULL default '',
  `classroomProduct` tinyint(1) NOT NULL default '0',
  `classroomCourseIDs` varchar(255) default NULL,
  `allowClassroomTrial` tinyint(1) NOT NULL default '0',
  `ceuPrompt` tinyint(1) NOT NULL default '0',
  `product_disabled` tinyint(1) NOT NULL default '0',
  `flatShipping` decimal(8,2) default NULL,
  `codeQuizProduct` tinyint(1) NOT NULL default '0',
  `codeQuizIDs` varchar(255) default NULL,
  `dvd_team_list` varchar(255) default NULL,
  `clearanceItem` tinyint(1) NOT NULL default '0',
  `originalPrice` decimal(8,2) default NULL,
  `replacement_product_id` int(11) default NULL,
  `prepubItem` tinyint(1) default NULL,
  `prePubText` varchar(255) default NULL,
  `what_people_say` longtext,
  PRIMARY KEY  (`product_id`),
  UNIQUE KEY `product_id` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='Product Information' AUTO_INCREMENT=1010 ;

-- --------------------------------------------------------

--
-- Table structure for table `product_bad`
--

CREATE TABLE IF NOT EXISTS `product_bad` (
  `product_id` mediumint(8) unsigned NOT NULL auto_increment,
  `category_id` mediumint(8) unsigned NOT NULL default '0',
  `category2_id` mediumint(8) default NULL,
  `pricing_id` mediumint(8) default NULL,
  `returnpolicy_id` tinyint(3) unsigned default NULL,
  `product_ceu_credit` enum('Yes','No') NOT NULL default 'No',
  `product_image` varchar(255) default NULL,
  `product_title` varchar(255) default NULL,
  `product_code` varchar(255) default NULL,
  `product_price` decimal(8,2) NOT NULL default '0.00',
  `product_taxable` enum('Yes','No') NOT NULL default 'Yes',
  `product_weight` decimal(5,1) NOT NULL default '0.0',
  `product_type` varchar(255) default '',
  `product_ISBN` varchar(255) default NULL,
  `product_page_count` varchar(255) default NULL,
  `product_illustration_count` varchar(255) default NULL,
  `product_video_type` varchar(255) default NULL,
  `product_description_student` text,
  `product_description_instructor` text,
  `product_available_date` varchar(255) default NULL,
  `product_pdf_toc` varchar(255) default NULL,
  `product_pdf_sample` varchar(255) default NULL,
  `product_graphic` varchar(255) default NULL,
  `product_graphic_border` text,
  `product_video` varchar(255) default NULL,
  `product_audio` varchar(255) default NULL,
  `product_modified` varchar(255) default NULL,
  `product_notes` text,
  `product_sort` float default NULL,
  `product_practice_question_count` varchar(255) default NULL,
  `product_link_text` varchar(255) default NULL,
  `product_link_url` varchar(255) default NULL,
  `product_exam_url` varchar(255) default NULL,
  `no_code_year` tinyint(1) NOT NULL default '1',
  `electronic_product` tinyint(1) NOT NULL default '0',
  `download_link` varchar(255) default NULL,
  `online_course` tinyint(1) NOT NULL default '0',
  `online_course_id` varchar(255) default NULL,
  `seminar` tinyint(1) NOT NULL default '0',
  `product_ISBN2` varchar(255) NOT NULL default '',
  `classroomProduct` tinyint(1) NOT NULL default '0',
  `classroomCourseIDs` varchar(255) default NULL,
  `allowClassroomTrial` tinyint(1) NOT NULL default '0',
  `ceuPrompt` tinyint(1) NOT NULL default '0',
  `product_disabled` tinyint(1) NOT NULL default '0',
  `flatShipping` decimal(8,2) default NULL,
  `codeQuizProduct` tinyint(1) NOT NULL default '0',
  `codeQuizIDs` varchar(255) default NULL,
  `dvd_team_list` varchar(255) default NULL,
  `clearanceItem` tinyint(1) NOT NULL default '0',
  `originalPrice` decimal(8,2) default NULL,
  `replacement_product_id` int(11) default NULL,
  `prepubItem` tinyint(1) default NULL,
  `prePubText` varchar(255) default NULL,
  `what_people_say` longtext,
  PRIMARY KEY  (`product_id`),
  UNIQUE KEY `product_id` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Product Information' AUTO_INCREMENT=956 ;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `rating_id` mediumint(8) unsigned NOT NULL auto_increment,
  `product_id` mediumint(8) unsigned default NULL,
  `rating_user_name` varchar(255) default NULL,
  `rating_user_email` varchar(255) default NULL,
  `rating_number` tinyint(2) unsigned NOT NULL default '1',
  `rating_text` text,
  `rating_approved` enum('Yes','No') NOT NULL default 'No',
  `rating_publish_email` enum('Yes','No') NOT NULL default 'No',
  `rating_modified` varchar(255) default NULL,
  PRIMARY KEY  (`rating_id`),
  UNIQUE KEY `rating_id` (`rating_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=372 ;

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE IF NOT EXISTS `receipt` (
  `receipt_id` int(20) unsigned NOT NULL auto_increment,
  `buyer_id` int(20) unsigned default NULL,
  `receipt_customer_number` varchar(255) default NULL,
  `receipt_first_name` varchar(255) default NULL,
  `receipt_middle_initial` varchar(255) default NULL,
  `receipt_last_name` varchar(255) default NULL,
  `receipt_email` varchar(255) default NULL,
  `receipt_company_name` varchar(255) default NULL,
  `receipt_company_title` varchar(255) default NULL,
  `receipt_company_website` varchar(255) default NULL,
  `receipt_address_1` varchar(255) default NULL,
  `receipt_address_2` varchar(255) default NULL,
  `receipt_city` varchar(255) default NULL,
  `receipt_state` varchar(255) default NULL,
  `receipt_country` varchar(255) default NULL,
  `receipt_zip` varchar(255) default NULL,
  `receipt_phone_day` varchar(255) default NULL,
  `receipt_phone_eve` varchar(255) default NULL,
  `receipt_phone_fax` varchar(255) default NULL,
  `receipt_customer_status` enum('New','Current') NOT NULL default 'New',
  `receipt_shipping_method` varchar(255) default NULL,
  `receipt_shipping_cost` varchar(255) default NULL,
  `receipt_payment_id` int(20) default NULL,
  `receipt_shipping_id` int(20) default NULL,
  `receipt_type` enum('Normal','Instructor') NOT NULL default 'Normal',
  `receipt_date` varchar(255) default NULL,
  `receipt_notes` text,
  `releaseElectronicProducts` tinyint(1) default '0',
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `receipt_physical_products` tinyint(4) default NULL,
  `receipt_orderWeight` int(11) default NULL,
  PRIMARY KEY  (`receipt_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43175 ;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_payment`
--

CREATE TABLE IF NOT EXISTS `receipt_payment` (
  `receipt_payment_id` int(20) unsigned NOT NULL auto_increment,
  `receipt_payment_method` varchar(255) default NULL,
  `receipt_payment_cc_number` varchar(255) default NULL,
  `receipt_payment_cc_expires` varchar(255) default NULL,
  `receipt_payment_cc_security_code` varchar(255) default NULL,
  `receipt_payment_purchase_order_number` varchar(255) default NULL,
  PRIMARY KEY  (`receipt_payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_product`
--

CREATE TABLE IF NOT EXISTS `receipt_product` (
  `receipt_product_id` int(20) unsigned NOT NULL auto_increment,
  `receipt_id` int(20) unsigned default NULL,
  `discount_code_id` int(20) unsigned default NULL,
  `receipt_product_code` varchar(255) default NULL,
  `receipt_product_title` varchar(255) default NULL,
  `receipt_product_price` varchar(255) default NULL,
  `receipt_product_qty` varchar(255) default NULL,
  `receipt_product_ceu` enum('True','False') NOT NULL default 'False',
  `receipt_return_policy_id` tinyint(3) unsigned default '0',
  `receipt_product_available_date` varchar(255) default NULL,
  `receipt_product_notes` text,
  `activated` tinyint(1) NOT NULL default '0',
  `product_id` mediumint(8) default NULL,
  PRIMARY KEY  (`receipt_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55875 ;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_shipping`
--

CREATE TABLE IF NOT EXISTS `receipt_shipping` (
  `receipt_shipping_id` int(20) unsigned NOT NULL auto_increment,
  `receipt_shipping_name` varchar(255) default NULL,
  `receipt_shipping_company` varchar(255) default NULL,
  `receipt_shipping_title` varchar(255) default NULL,
  `receipt_shipping_street_address_1` varchar(255) default NULL,
  `receipt_shipping_street_address_2` varchar(255) default NULL,
  `receipt_shipping_city` varchar(255) default NULL,
  `receipt_shipping_state` varchar(255) default NULL,
  `receipt_shipping_country` varchar(255) default NULL,
  `receipt_shipping_zip` varchar(255) default NULL,
  `receipt_shipping_phone_day` varchar(255) default NULL,
  `receipt_shipping_phone_eve` varchar(255) default NULL,
  `receipt_shipping_physical_products` tinyint(11) NOT NULL default '0',
  PRIMARY KEY  (`receipt_shipping_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44069 ;

-- --------------------------------------------------------

--
-- Table structure for table `related_products`
--

CREATE TABLE IF NOT EXISTS `related_products` (
  `related_products_id` int(20) unsigned NOT NULL auto_increment,
  `product_id` mediumint(8) unsigned default NULL,
  `related_product_id` mediumint(8) unsigned default NULL,
  PRIMARY KEY  (`related_products_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=375 ;

-- --------------------------------------------------------

--
-- Table structure for table `returnpolicy`
--

CREATE TABLE IF NOT EXISTS `returnpolicy` (
  `returnpolicy_id` tinyint(3) unsigned NOT NULL auto_increment,
  `returnpolicy_title` varchar(255) default NULL,
  `returnpolicy_text` text,
  `returnpolicy_modified` varchar(255) default NULL,
  PRIMARY KEY  (`returnpolicy_id`),
  UNIQUE KEY `returnpolicy_id` (`returnpolicy_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `state_id` tinyint(2) unsigned NOT NULL auto_increment,
  `state_code` varchar(255) NOT NULL default '',
  `state_name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`state_id`),
  UNIQUE KEY `ID` (`state_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=95 ;
