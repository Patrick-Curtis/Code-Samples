<?
class User extends Controller
{

    function User()
    {
        parent::Controller();
    }

    function main()
    {
        $this->load->model('user_model');
        $data = $this->user_model->general();
        $data['query'] = $this->user_model->list_users();
        $data['websubtitle']= 'User List';
        $this->load->model('User_permissions_model','', TRUE);
        $data['user_permissions'] = $this->User_permissions_model->list_user_permissions();
        $this->load->view('user_main',$data);
    }

    function add()
    {
        $this->load->helper('form');

		$this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[4]|max_length[12]|callback_username_check');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check');
        $this->form_validation->set_rules('password', 'Password', 'required|matches[passconf]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required');
        $this->form_validation->set_rules('permission_id', 'Permission', 'required|is_not_selected');

        if ($this->form_validation->run() == FALSE) //  FAILED VALIDATION
		{
            $this->load->model('User_model');
            $data = $this->User_model->general();
            $data['websubtitle']= 'Add User';
            $this->load->model('User_permissions_model','', TRUE);
            $data['user_permissions'] = $this->User_permissions_model->list_user_permissions();
			$this->load->view('user_add',$data);
		}
		else //  PASSED VALIDATION
		{
			$this->load->model('User_model');
            $data = $this->User_model->general();
            $data['websubtitle']= 'Add User Success!';
            $data['id'] = $this->User_model->add_user();
            $data['query'] = $this->User_model->get_user($data['id']);
            $this->load->model('User_permissions_model','', TRUE);
            $data['user_permissions'] = $this->User_permissions_model->list_user_permissions();
            $this->load->view('user_detail',$data);
		}
    }

    function edit($id = NULL)
    {
        if($id == NULL){ $id = $this->uri->segment(3); }
        $this->id = $id;

        $this->load->helper('form');

		$this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[4]|max_length[12]|callback_edit_username_check');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_edit_email_check');
        $this->form_validation->set_rules('password', 'Password', 'required|matches[passconf]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required');
        $this->form_validation->set_rules('permission_id', 'Permission', 'required|is_not_selected');

        $this->load->model('User_model');
        $data = $this->User_model->general();

        //  FAILED VALIDATION
        if ($this->form_validation->run() == FALSE)
		{
            $data['query'] = $this->User_model->get_user($id);
            $data['websubtitle']= 'Edit User';
            $this->load->model('User_permissions_model','', TRUE);
            $data['user_permissions'] = $this->User_permissions_model->list_user_permissions();
			$this->load->view('user_edit',$data);
		}
		else //  PASSED VALIDATION
		{
            $data['websubtitle']= 'Edit User Result!';
            $data['id'] = $this->User_model->edit_user();
            $data['query'] = $this->User_model->get_user($data['id']);
            $this->load->model('User_permissions_model','', TRUE);
            $data['user_permissions'] = $this->User_permissions_model->list_user_permissions();
            $this->load->view('user_detail',$data);
		}
    }

	function edit_username_check($str)
	{
        //  PREVENT USERNAME DUPLICATES
        $query = $this->db->query("SELECT * FROM users where username = '$str' AND id != '{$this->id}'");
        $cnt = $query->num_rows();
		if ($cnt)
		{
			$this->form_validation->set_message('edit_username_check', 'The %s ' . $str . ' is already in use');
			return FALSE;
		}
        return TRUE;
	}

	function edit_email_check($str)
	{
        //  PREVENT EMAIL DUPLICATES
        $query = $this->db->query("SELECT * FROM users where email = '$str' AND id != '{$this->id}'");
        $cnt = $query->num_rows();
		if ($cnt)
		{
			$this->form_validation->set_message('edit_email_check', 'The %s ' . $str . ' is already in use');
			return FALSE;
		}
        return TRUE;
	}

}
?>