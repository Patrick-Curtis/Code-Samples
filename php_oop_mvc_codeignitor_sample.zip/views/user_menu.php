
<?php echo $menu; ?>