<code>
<?php echo $webfooter; ?>
</code>