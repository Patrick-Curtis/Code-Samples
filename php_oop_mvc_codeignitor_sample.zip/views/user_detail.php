<html>
<head>
<link rel="stylesheet" type="text/css" href="<?php echo "$base/$css"?>">
</head>
<body>
    <div id="header">
    <? $this->load->view('user_header'); ?>
    </div>
    <div id="menu">
    <? $this->load->view('user_menu'); ?>
    </div>

<?
echo $query['username'] . " was successfully added!<br>";    //    DEBUG
?>
    <div id="footer">
    <? $this->load->view('user_footer'); ?>
    </div>
</body>
</html>