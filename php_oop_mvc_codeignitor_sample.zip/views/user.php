<html>
<head>

</head>
<body>
    <div id="header">
    <? $this->load->view('user_header'); ?>
    </div>
    <div id="menu">
    <? $this->load->view('user_menu'); ?>
    </div>

    test list

    <div id="footer">
    <? $this->load->view('user_footer'); ?>
    </div>
</body>
</html>