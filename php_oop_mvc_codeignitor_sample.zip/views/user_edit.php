<html>
<head>
<link rel="stylesheet" type="text/css" href="<?php echo "$base/$css"?>">
</head>
<body>
    <div id="header">
    <? $this->load->view('user_header'); ?>
    </div>
    <div id="menu">
    <? $this->load->view('user_menu'); ?>
    </div>

<? //print_r($query);    //    DEBUG ?>
<?php echo form_open('user/edit/' . $query['id']); ?>
<table width="770" border="0" align="center" cellpadding="1" cellspacing="0" bgcolor="#cccccc">
  <tr>
    <th style="text-align:center;">Edit User</th>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="8" bgcolor="#ffffff">
      <tr>
        <td colspan="2" align="center">[ All Fields Required ]</td>
        </tr>
      <tr>
        <td><strong>Username</strong></td>
        <td><input type="text" name="username" value="<?= (set_value('username') == NULL)? $query['username'] : set_value('username') ?>" size="30" />
          <?= (form_error('username'))? ' &nbsp; ' . strip_tags(form_error('username')): ''; ?>
          <input type="hidden" name="id" value="<?php echo $query['id']; ?>" />
          </td>
      </tr>
      <tr>
        <td><strong>Email</strong></td>
        <td><input type="text" name="email" value="<?= (set_value('email') == NULL)? $query['email'] : set_value('email') ?>" size="30" />
          <?= (form_error('email'))? ' &nbsp; ' . strip_tags(form_error('email')): ''; ?></td>
      </tr>
      <tr>
        <td><strong>Password</strong></td>
        <td><input type="text" name="password" value="<?= (set_value('password') == NULL)? $query['password'] : set_value('password') ?>" size="30" />
          <?= (form_error('password'))? ' &nbsp; ' . strip_tags(form_error('password')): ''; ?></td>
      </tr>
      <tr>
        <td><strong>Password Confirm</strong></td>
        <td><input type="text" name="passconf" value="<?= (set_value('passconf') == NULL)? $query['password'] : set_value('passconf') ?>" size="30" />
          <?= (form_error('passconf'))? ' &nbsp; ' . strip_tags(form_error('passconf')): ''; ?></td>
      </tr>
      <tr>
        <td><strong>Permission</strong></td>
        <td>
 <?php
//  CREATE PERMISSIONS SELECT BOX
$options = array('0' => 'Select One');
foreach($user_permissions as $user_permission)
{
    $options[$user_permission['permission_id']] = $user_permission['permission'];
    //echo "$user_permission[permission_id] => $user_permission[permission]<br>";    //    DEBUG
}
echo form_dropdown('permission_id', $options, $query['permission_id']);
?>
<?= (form_error('permission_id'))? ' &nbsp; ' . strip_tags(form_error('permission_id')): ''; ?></td>
      </tr>
      <tr>
        <td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="4">
        <br />
          <tr>
            <td width="33%" align="center"><input type="button" value="Cancel" onClick="document.location='<?= $base ?>user/main'" /></td>
            <td width="34%" align="center"><input type="button" value="Reset" onClick="document.location='<?= $base ?>user/edit/<?= $query['id'] ?>'" /></td>
            <td width="33%" align="center"><input type="submit" value="Update" /></td>
            </tr>
          </table>
        <br />
          </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</form>
    <div id="footer">
    <? $this->load->view('user_footer'); ?>
    </div>
</body>
</html>