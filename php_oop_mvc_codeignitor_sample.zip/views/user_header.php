<h1 id="title">
<?php echo $webtitle; ?>
<div style="float: right; font-size: 1em; font-weight: normal; padding-right: 12px;">
CI::Applications <a href="<?= $_SERVER['PHP_SELF'] ?>">Home</a>
</div>
</h1>
<h2>
<?php echo $websubtitle; ?>
<div style="float: right; font-size: 1em; font-weight: normal; padding-right: 12px;">
[Username and Email must be Unique]
</div>
</h2>
