<html>
<head>
<link rel="stylesheet" type="text/css" href="<?php echo "$base/$css"?>">
<title>User List</title>
<!-- BELOW IS PURELY FOR DW ONLY -->
<link href="../../../css/style.css" rel="stylesheet" type="text/css">
<?php
//  KEEP THIS WHEN LIVE
$this->load->helper('html');
echo link_tag('css/style.css');
// GET USER PERMISSIONS AS AN ARRAY
$aUPERMS = array();
foreach($user_permissions as $user_permission)
{
    //echo $user_permission['permission_id'] . "<br>";    //    DEBUG
   $aUPERMS[$user_permission['permission_id']] = $user_permission['permission'];
}
?>
</head>
<body>
    <div id="header">
    <? $this->load->view('user_header'); ?>
    </div>
    <div id="menu">
    <? $this->load->view('user_menu'); ?>
    </div>

    <div id="main">
    <table width="98%" border="0" cellspacing="0" cellpadding="4" bgcolor="#ffffff" align="center">
      <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Password</th>
        <th>Permission</th>
      </tr>
<?php
if(
is_array($query)
&&
sizeof($query)
):
    foreach($query AS $row):
?>
      <tr>
        <td><?= anchor('user/edit/' . $row['id'], $row['username'],array('title' => 'Edit User: '.$row['username'])) ?>&nbsp;</td>
        <td><a href="mailto:<?= $row['email'] ?>?subject=User Application Demonstration&body=" title="Email : <?= $row['email'] ?>"><?= $row['email'] ?></a>&nbsp;</td>
        <td><?= $row['password'] ?>&nbsp;</td>
        <td><?= $aUPERMS[$row['permission_id']] ?>&nbsp;</td>
      </tr>
<?php endforeach; ?>
<?php else: ?>
      <tr>
        <td colspan="4" align="center">There are no users to view</td>
      </tr>
<?php endif; ?>
    </table>
<p class="elapsed_time"><br />Page rendered in {elapsed_time} seconds</p>
</div>
    <div id="footer">
    <? $this->load->view('user_footer'); ?>
    </div>
</body>
</html>