<?php
class User_permissions_model extends Model
{
  function User_permissions_model()
  {
    parent::Model();
  }

  function list_user_permissions()
  {
    $query = $this->db->query("SELECT * FROM user_permissions");
    $ret = $query->result_array();
    //print_var($ret);  //  DEBUG
    return $ret;
  }
}
?>
