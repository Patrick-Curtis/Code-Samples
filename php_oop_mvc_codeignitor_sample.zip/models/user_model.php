<?
class user_model extends Model{

    function user_model()
    {
        parent::Model();
        $this->load->helper('url');
    }
    function general()
    {
        $this->load->library('UserMenu');

        $menu = new UserMenu;
        $data['base']       = $this->config->item('base_url');
        $data['css']        = $this->config->item('css');
        $data['menu'] 		= $menu->show_menu();
        $data['webtitle']	= 'CI::User Registration Demonstration';
        $data['websubtitle']= 'Administer Users';
        $data['webfooter']	= '&copy;' . date("Y") . ' <a href="http://patcurtis.com" target="_blank">Pat Curtis Consulting</a>';

        return $data;
    }
    function list_users()
    {
        $query = $this->db->query("SELECT * FROM users");
        $ret = $query->result_array();
        return $ret;
    }
    function get_user($id=1)
    {
        $query = $this->db->getwhere('users',array('id'=>$id));
        if($query->num_rows())
        {
            return $query->row_array();
        }
        return false;
    }
    function add_user()
    {
        $data = array(
             'id'               =>    '',
             'username'         =>    $this->input->post('username'),
             'email'            =>    $this->input->post('email'),
             'password'         =>    $this->input->post('password'),
             'permission_id'    =>    $this->input->post('permission_id')
        );
        return $this->db->insert('users', $data);
    }
    function edit_user()
    {
        $data = array(
             'id'               =>    $this->input->post('id'),
             'username'         =>    $this->input->post('username'),
             'email'            =>    $this->input->post('email'),
             'password'         =>    $this->input->post('password'),
             'permission_id'    =>    $this->input->post('permission_id')
        );
        $this->db->where('id', $data['id']);
        return $this->db->update('users', $data);
    }
}
?>