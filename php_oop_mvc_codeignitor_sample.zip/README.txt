This is some sample OOP MVC taken from a demonstration on my web site located here:

http://patcurtis.com/codeignitor/

Never finished the delete functinality but would be easy so should probably do it.