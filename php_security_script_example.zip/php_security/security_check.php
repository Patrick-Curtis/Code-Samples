<?
//-----------------------------------//
//	12/23/2006 -PC
//	BEGIN HACKER PREVENTION CODE
//	THIS FILE SHOULD BE CALLED AFTER ANY SESSION
//	CODE AND BEFORE CALLING THE mail() FUNCTION
//	EXAMPLE: require_once("[relative-path]/security_check.php");
//-----------------------------------//
//-----------------------------------//
//	SET UP TO CHECK FOR ALLOWED HOSTS
//	www.yourwebsite.com	// YOUR WEB SITE
//-----------------------------------//
//-----------------------------------//
//	MAKE SURE THIS CAME FROM A VALID HOST
//	THERE ARE 4 POSSIBLE SITUATIONS:
//	1. CLICKING ON A DOWNLOADED WEB PAGE (after tweaking)
//	2. CLICKING ON A DOWNLOADED WEB PAGE THROUGH A LOCAL SERVER (after tweaking)
//	3. CLICKING ON A DOWNLOADED WEB PAGE AFTER UPLOADING TO ANOTHER SERVER (after tweaking)
//	4. CLICKING ON A VALID FORM ON THE REAL HOST WEB SITE
//-----------------------------------//
//-----------------------------------//
//	ARRAY OF APPROVED SERVERS/DOMAINS AND A FLAG
//	THAT INDICATES WHETHER OR NOT USE THE ARRAY
//	DEFAULT IS TO NOT USE THE LIST
//-----------------------------------//
//$useApprovedServersList = 0;	// DEFAULT - CHANGE TO '1' IF YOU WANT TO USE A LIST
$useApprovedServersList = 0;    //  7/9/2008 RELAX THIS FOR NOW _PC
//-----------------------------------//
//	IF YOU ARE USING AN APPROVAL LIST YOU MUST
//	INCLUDE YOUR DOMAIN IN THE ARRAY BELOW!
//-----------------------------------//
$aApprovedReferers = array('www.patcurtis.com','patcurtis.com','localhost','127.0.0.1');
//$aApprovedReferers = array('www.yourdomain.com','www.otherdomain.com','ipaddress', etc.);
//-----------------------------------//
//	DEFINE THE ALLOWED METHODS FOR REACHING THIS SCRIPT
//	THIS IS A BOOLEAN 0 = POST, 1 = GET
//	USING POST IS RECOMMENDED AND SO IS THE DEFAULT
//-----------------------------------//
$aAllowedMethods = 0;	// DEFAULT IS '0' POST METHOD
if(!$aAllowedMethods){
	if($_GET){
		echo "Please go away ".$_SERVER['REMOTE_ADDR']."<br>";
		exit;
	} else {
		$form = $_POST;
	}
} else {
	$form = $_GET;
}
//-----------------------------------//
//	STEP ONE
//	CHECK REFERING VALUE I.E.
//	A STATIC PAGE CLICKED ON FROM A REMOTE COMPUTER
//	A STATIC PAGE WON'T HAVE ANY $HTTP_REFERER INFORMATION
//-----------------------------------//
if(!$_SERVER['HTTP_REFERER']){
	echo "Please go away ".$_SERVER['REMOTE_ADDR']."<br>";
	exit;
} else {
	//-----------------------------------//
	//	STEP TWO
	//	IF THEY HAVE A WEB SERVER RUNNING ON THEIR LOCAL COMPUTER
	//	IT WILL SEND IT'S ADDRESS INFORMATION - USUALLY LOOKS LIKE THIS
	//	http://127.0.0.1[:port][/dir]/page OR ...
	//	http://localhost[:port][/dir]/page
	//	ALSO, THEY MIGHT UPLOAD THE 'HACKED' FORM TO ANOTHER SERVER AND TRY IT THERE
	//	http://www.someserver.com[:port][/dir]/page
	//	HERE'S WHERE DEFINED HTTP PROTOCOL COMES IN
	//	WE CAN COMPARE THE CALLING HOST AGAINST OUR HOST ADDRESS
	//-----------------------------------//
	//-----------------------------------//
	//	GET THE CALLING HOST
	//-----------------------------------//
	$aCallerHostTmp = str_replace("http://", "", strtolower($_SERVER['HTTP_REFERER']));
	$aCallerHost = explode("/", $aCallerHostTmp);
	//echo "REMOTE HOST: ".$aCallerHost[0]."<br>";	// DEBUG COMMENT THIS OUT WHEN LIVE
	//-----------------------------------//
	//	GET OUR HOST
	//-----------------------------------//
	$aOurHostTmp = str_replace("http://", "", strtolower($_SERVER['HTTP_HOST']));
	$aOurHost = explode("/", $aOurHostTmp);
	//echo "OUR HOST: ".$aOurHost[0]."<br>";	// DEBUG COMMENT THIS OUT WHEN LIVE
	//-----------------------------------//
	//	STEP THREE
	//	EXCLUDE INFO SENT FROM A FOREIGN OR [OPTIONAL] UNAPPROVED SERVER
	//	IF FROM FOREIGN OR NOT APPROVED REFERER DO SOMETHING
	//	FIRST CHECK TO SEE IF WE ARE USING AN APPROVAL LIST
	//-----------------------------------//
	if($useApprovedServersList){
		if(!in_array(strtolower($aCallerHost[0]),$aApprovedReferers)){
			//-----------------------------------//
			//	OPTIONS: ADD CODE TO ... USE YOUR IMAGINATION
			//	1. SEND AN EMAIL ABOUT THIS TO THE SITE ADMIN OR
			//	2. RECORD IT TO A SPECIAL LOG WITH THE PERSON'S
			//	IP ADDRESS, SERVER IT CAME FROM, ETC.
			//-----------------------------------//
			echo "Please Go Away ".$_SERVER['REMOTE_ADDR']."<br>";
			exit;
		} else {
			//-----------------------------------//
			//	CONTINUE PROCESSING THE FORM
			//	CALL THE FIELD CHECKING SCRIPT
			//-----------------------------------//
			CheckFormFields($form);
			//echo "<br>This form was submitted from an approved site<br>";	// DEBUG COMMENT THIS OUT WHEN LIVE
			//return;	// DEBUG
		}
	//-----------------------------------//
	//	IF YOU ARE NOT USING AN APPROVAL LIST
	//-----------------------------------//
	} else {
		if($aOurHost[0] != $aCallerHost[0]){
			//-----------------------------------//
			//	OPTIONS: ADD CODE TO ... USE YOUR IMAGINATION
			//	1. SEND AN EMAIL ABOUT THIS TO THE SITE ADMIN OR
			//	2. RECORD IT TO A SPECIAL LOG WITH THE PERSON'S
			//	IP ADDRESS, SERVER IT CAME FROM, ETC.
			//-----------------------------------//
			echo "Please Go Away ".$_SERVER['REMOTE_ADDR']."<br>";
			exit;
		} else {
			//-----------------------------------//
			//	JUST CONTINUE WITH THE FORM PROCESSING
			//-----------------------------------//
			CheckFormFields($form);	// SEE FUNCTION BELOW
			//echo "This form was submitted from an approved site<br>";	// DEBUG COMMENT THIS OUT WHEN LIVE
			//return;	// DEBUG
		}
	}
}

//-----------------------------------//
//	SEC CHECK ALL FORM FIELDS
//	YOU CAN ADD ADDITIONAL FUNCTIONS HERE
//	IF YOU'RE A PROGRAMMER, YOU KNOW WHAT TO DO
//	THIS SHOULD DO YA UNTIL THE NEXT HACK COMES OUT
//-----------------------------------//
function CheckFormFields($form){
	$isOkay = true;	// ASSUME ALL IS OKAY UNTIL PROVEN WRONG
	while(list($k,$v)=each($form)){
		//echo "$k => $v<br>";	// DEBUG
		if(
		//(!has_no_newlines($v))
		//&&
		(!has_no_emailheaders($v))
		&&
		(!CheckMultipart($v))
		&&
		(!DisEmailChains($v))
		&&
		(!DisLinks($v))
		){
			//echo "<br>Field $k is cool!<br>";	// DEBUG
		} else {
			//echo "<br>Having a Problem with the '$k' field!<br>";	// DEBUG
			$isOkay = false;
		}
	}
	if(!$isOkay){
		//echo "<br>Encountered a Problem with One or More Form Fields!<br>";	// DEBUG
		echo "<br>Please Go Away ".$_SERVER['REMOTE_ADDR']."<br>";
		exit;
	}
}

//-----------------------------------//
//	THE BELOW CODE IS EXCERPTED FROM
//	http://php.he.net/manual/en/ref.mail.php#62027
//  DISABLE THIS IF YOU HAVE TEXTAREA FIELDS
//-----------------------------------//
function has_no_newlines($text){
    if(is_string($text)){
    	if(preg_match("/(%0A|%0D|\\n+|\\r+)/i", $text)){
    		//return true;
    		return false;   //  DISABLED THIS
    	} else {
    		return false;
    	}
    }
}

function has_no_emailheaders($text){
    if(is_string($text)){
    	if(preg_match("/(%0A|%0D|\\n+|\\r+)(content-type:|to:|cc:|bcc:)/i", $text)){
    		return true;
    	} else {
    		return false;
    	}
    }
}
//-----------------------------------//
//	RICH YUMUL CHECK INCLUDED
//	rmy@sdtechnix.com
//-----------------------------------//
function CheckMultipart($text){
	if(stristr($text, "Content-Type: multipart/mixed")){
		return true;
	} else {
		return false;
	}
}

//-----------------------------------//
//	PREVENT CHAINING EMAIL ADDRESSES IN A FORM FIELD
//-----------------------------------//
function DisEmailChains($text){
	//echo "You sent $text to DisEmails<br>";	// DEBUG
	if(stristr($text, '@')){	// SIMPLE CHECK TO SEE IF THIS IS AN EMAIL ADDRESS - GO AS CRAZY AS YOU WANT
		if(stristr($text, ",")){
			return true;
		} else {
			return false;
		}
	}
	return false;	// DEFAULT IS FALSE - SKIPS FIELDS THAT ARE IMPROPERLY FORMATTED
}

//-----------------------------------//
//  PREVENT ENTERING LINKS
//-----------------------------------//
function DisLinks($text){
	//echo "You sent $text to DisLinks<br>";	// DEBUG
	if(
	    stristr($text, 'http') or
	    stristr($text, 'www') or
	    stristr($text, '[link]')
	   ){
		return true;
	}
	return false;	// DEFAULT IS FALSE - SKIPS FIELDS THAT ARE IMPROPERLY FORMATTED
}

//-----------------------------------//
//  SIMPLE SERVER SIDE EMAIL FORMAT VALIDATION FUNCTION
//-----------------------------------//
function CheckEmailFormat($email){
    if(eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)) {
        return true;
    }
    return false;
}

//-----------------------------------//
//	DEBUG - PROGRAMMER INFORMATION ONLY
//-----------------------------------//
/*
echo "<center>";
echo "HTTP_REFERER: ".$_SERVER['HTTP_REFERER']."<br>";
echo "<br>";
echo "REMOTE_ADDR: ".$_SERVER['REMOTE_ADDR']."<br>";
echo "<br>";
echo "HTTP_HOST: ".$_SERVER['HTTP_HOST']."<br>";
echo "<br>";
*/

//-----------------------------------//
//	POST VARS
//-----------------------------------//
/*
echo "<pre>";
while(list($k,$v)=each($_POST)){
echo "$k => $v<br>";
}
echo "</center>";
echo "</pre>";
*/
//-----------------------------------//
//	GET VARS
//-----------------------------------//
/*
echo "<pre>";
while(list($k,$v)=each($_GET)){
echo "$k => $v<br>";
}
echo "</center>";
echo "</pre>";
*/
?>
