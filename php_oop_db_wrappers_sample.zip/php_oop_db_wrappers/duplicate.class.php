<?
//-----------------------------------//
//  PREVENTS DB ERRORS FOR CRITICAL [UNIQUE] KEYS
//-----------------------------------//
class DbProtect extends db {
    //-----------------------------------//
    //  mixed PreventDuplicate(string $table, string $column, string $value)
    //-----------------------------------//
    public function PreventDuplicate($table, $column, $value){
        $row = '';
        $sql = "SELECT $column FROM $table WHERE $column = '$value' LIMIT 0,1";
        //echo "\$sql => $sql<br>";    //    DEBUG
        $resID = $this->query($sql);
        if($resID){
            $row = $this->db_fetch_assoc($resID);
            //echo $row[$column] . "<br>";    //    DEBUG
            return $row[$column];
        }
        return false;
    }   //  END     P r e v e n t D u p l i c a t e ()

}
?>