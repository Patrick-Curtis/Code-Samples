<?
// THIS IS YOUR TABLE ARRAY

//-----------------------------------//
//  HANDLES FUNCTIONS FOR THE CONTACT TABLE
//-----------------------------------//
class Contact extends db {

    protected   $aContact = array(
        		'contact_id'            => '',  //  INT 20 PRIMARY UNIQUE AUTO INCREMENT
        		'contact_first_name'    => '',  //  VARCHAR(255) NULL
        		'contact_mi'            => '',  //  VARCHAR(1) NULL
        		'contact_last_name'     => '',  //  VARCHAR(255) NULL
        		'contact_email'         => '',  //  VARCHAR(255) UNIQUE
        		'contact_password'      => '',  //  VARCHAR(255) NULL
        		'contact_modified'      => ''   //date("YmdHis")  //  VARCHAR(255) NULL DO NOT PASS THIS IN YOUR FORM
                );

    protected $aContactLength;

    //-----------------------------------//
    //  int aInsertaContactLength()
    //  GETS LENGTH OF YOUR DEFAULT ARRAY
    //-----------------------------------//
    public function aInsertaContactLength(){
        $this->aContactLength = sizeof($this->aContact);
        //echo "array \$aContact has " . $this->aContactLength . " elements<br>";    //    DEBUG
        return $this->aContactLength;
    }   // END    a I n s e r t a C o n t a c t L e n g t h ( )

    //-----------------------------------//
    //  mixed InsertContact(array $InForm)
    //  INSERTS NEW RECORD
    //-----------------------------------//
    public function InsertContact($InForm){
        $this->InForm = $InForm;
        //  PREVENT DUPLICATE EMAIL ACCOUNTS
        $email_exists = DbProtect::PreventDuplicate('contact', 'contact_email', $this->InForm['contact_email']);
        if(!$email_exists){
            $dbArray = array_slice(array_merge($this->aContact, $this->InForm),0,$this->aInsertaContactLength());
            $this->dbArray = $dbArray;
            return (int) $this->db_insert_list('contact', $this->dbArray);
        } else {
            echo "$email_exists exists!<br>";    //    DEBUG
            return "$email_exists";
        }
    }   //  END    I n s e r t C o n t a c t ( $ I n F o r m )

    //-----------------------------------//
    //  mixed UpdateContact(array $InForm)
    //  UPDATE EXISTING RECORD
    //-----------------------------------//
    public function UpdateContact($InForm) {
        $this->InForm = $InForm;
        $this->email_exists = '';
        //  PREVENT DUPLICATE EMAIL ACCOUNTS
        if($this->InForm['contact_email'] != $this->InForm['current_email']){
            $this->email_exists = DbProtect::PreventDuplicate('contact', 'contact_email', $this->InForm['contact_email']);
            //echo "You Changed your email address!<br>";    //    DEBUG
        }
        if(!$this->email_exists){
        	//  ENSURE A RECORD WITH THIS ID EXISTS
        	$this->id = $InForm['contact_id'];
        	$this->id_check = $this->query("select * from contact WHERE contact_id = '$this->id'");
         	if($this->id_check) {
                $dbArray = array_slice(array_merge($this->aContact, $this->InForm),0,$this->aInsertaContactLength());
                $this->dbArray = $dbArray;
        		$this->result = $this->db_update_list('contact', $this->dbArray, 'contact_id', $this->id);
                if($this->result){
                    //echo $this->id . "<br>";
                    return $this->id;
                } else {
                    echo "Could not update record#: <br>";    //    DEBUG
                }
        	} else {
                echo "Could not find a record#: $this->id<br>";    //    DEBUG
        	}
        } else {
            echo "$this->email_exists exists!<br>";    //    DEBUG
            return "$this->email_exists";
        }
     	return false;
    } // END   U p d a t e C o n t a c t ( $ I n F o r m )

    //-----------------------------------//
    //  array ReadContact($contact_id)
    //-----------------------------------//
    public function ReadContact($contact_id) {
        $sql = "select * from contact WHERE contact_id = '$contact_id'";
        //echo "\$sql => $sql<br>";    //    DEBUG
        $resID = $this->query($sql);
        return $this->db_fetch_assoc($resID);
    } // END   R e a d C o n t a c t ( $ i d )

    //-----------------------------------//
    //  bool DeleteContact($contact_id)
    //-----------------------------------//
    public function DeleteContact($contact_id) {
    	//  ENSURE A RECORD WITH THIS ID EXISTS
    	$this->id = $contact_id;
    	$this->id_check = $this->query("select * from contact WHERE contact_id = '$this->id'");
        if($this->id_check) {
			$sql = "DELETE FROM contact WHERE contact_id = '$this->id' LIMIT 1";
			$this->deleted = $this->query($sql);
			return $this->deleted;
		} else{
		    echo "Could not find ID: <br>" . $this->id;    //    DEBUG
        }
    	return false;
    } // END  D e l e t e C o n t a c t ( $ i d )

    //-----------------------------------//
    //  resource ContactList(int $begin, int $limit, string $orderby)
    //-----------------------------------//
    public function ContactList($begin = '0', $limit = '0,100', $orderby = 'contact_last_name, contact_first_name'){
        $this->orderby = $orderby;
        $this->limit = $limit;
        $sql = "select * from contact ORDER BY $this->orderby LIMIT $this->limit";
        return $this->query($sql);
    }

    //-----------------------------------//
    //  int CountContacts(int $count_limit)
    //-----------------------------------//
    public function CountContacts($count_limit=25){
        $sql = "select COUNT(*) AS COUNT from contact LIMIT 0, $count_limit";
        $resID = $this->query($sql);
        $this->row = $this->db_fetch_assoc($resID);
        $this->contact_count = $this->row['COUNT'];
        return $this->contact_count;
    }

}   //  END     c l a s s  C o n t a c t ( )

/* END contact.class.php */
?>