<?
class db {
    //-----------------------------------//
    //  BASIC CONNECT FUNCTIONS
    //-----------------------------------//
     protected $hostname;
     protected $username;
     protected $password;
     protected $database;
     protected $connect;
     protected $select_db;
     protected $ret;
     protected $lastID;

     public function db() {
          $this->hostname = "localhost";
          $this->username = "root";
          $this->password = "";
          $this->database = "awecsv";
     }

     public function open_connection() {
          try {
               $this->connect = mysql_connect($this->hostname,$this->username,$this->password);
               $this->select_db = mysql_select_db($this->database);
          }
          catch(exception $e) {
               return $e;
          }
     }

     public function close_connection() {
          try {
               mysql_close($this->connect);
          }
          catch(exception $e) {
               return $e;
          }
     }

     public function query($sql) {
          try {
               $this->open_connection();
               $sql = mysql_query($sql);
          }
          catch(exception $e) {
               return $e;
          }
          $this->close_connection();
          return $sql;
     }
    //-----------------------------------//
    //  MY CUSTOM FUNCTIONS
    //-----------------------------------//
    //-----------------------------------//
    //  INSERTS A ROW IN DB - PROTECTS AGAINST ILLEGAL CHARS & MYSQL INJECTION HACKS
    //  int db_insert_list( string $table, array $data_list)
    //-----------------------------------//
    public function db_insert_list($table, $data_list) {
        try {
        $this->open_connection();
        }
        catch(exception $e) {
           return $e;
        }
        $query = "INSERT INTO $table (";
        while (list($column, $value) = each($data_list)) {
            $columns[] = $column;
            $values[]  = "'" .mysql_real_escape_string($value). "'";
        }
        $query = $query
           . implode($columns, ", ")
           . ") VALUES ("
           . implode($values, ", ")
           . ")";
        //  echo "QUERY RESULT IN DB FILE IS $query<br>";   //  DEBUG
    	$this->ret = mysql_query($query);
    	if (!$this->ret):
    		echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here (e.g. log errors)
    		return false;
    	endif;
    	$this->lastID = mysql_insert_id($this->connect);
        //echo "Last ID: " . $this->lastID . "<br>";    //    DEBUG
    	return $this->lastID;

    } // E N D   d b _ i n s e r t _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ e n d _ c o u n t )

    //-----------------------------------//
    //  UPDATE A ROW IN THE DB
    //  int db_update_list(string $table, array $data_list, string (name of $id column) $id_name, index $id)
    //-----------------------------------//
    protected function db_update_list($table, $data_list, $id_name, $id) {
        try {
        $this->open_connection();
        }
        catch(exception $e) {
           return $e;
        }
    	$end_count = sizeof($data_list);
     	$query = "UPDATE $table SET ";
    	$key = array_keys($data_list);
    	$val = array_values($data_list);
    	for ($i = 1; $i < $end_count; $i++){
    		if($i == $end_count-1){
                $query = $query. $key[$i]. "='" .mysql_real_escape_string($val[$i]). "'";
    		}else{
    			$query = $query. $key[$i]. "='" .mysql_real_escape_string($val[$i]). "', ";
    		}
    	}
    	$query = $query. " WHERE $id_name='$id'";
        //  echo "QUERY RESULT IN DB FILE IS $query<br>";   //  DEBUG
    	$this->ret = mysql_query($query);
    	if (!$this->ret):
    		echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here (e.g. log errors)
    		return false;
    	endif;
    	$this->lastID = mysql_insert_id($this->connect);
        //echo "Last ID: " . $this->lastID . "<br>";    //    DEBUG
    	return $this->lastID;

    } // E N D   d b _ u p d a t e _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ i d _ n a m e ,   $ i d )

    //-----------------------------------//
    //  GET A key->val ASSOCIATIVE ARRAY FROM THE RESOURCE SUPPLIED
    //  array db_fetch_assoc( db resource ID $resourceID)
    //-----------------------------------//
    public function db_fetch_assoc($resourceID) {
        try {
        $this->open_connection();
        }
        catch(exception $e) {
           return $e;
        }
    	return mysql_fetch_assoc($resourceID);
    }   //  END d b _ f e t c h _ a s s o c ( $ r e s o u r c e I D )

    //-----------------------------------//
    //  GET AN int INDEXED ARRAY FROM THE RESOURCE SUPPLIED
    //  array db_fetch_row( db resource ID $resourceID)
    //-----------------------------------//
    public function db_fetch_row($resourceID) {
        try {
        $this->open_connection();
        }
        catch(exception $e) {
           return $e;
        }
    	return db_fetch_row($resourceID);
    }   //  END d b _ f e t c h _ r o w ( $ r e s o u r c e I D )

    //-----------------------------------//
    //  RETURNS ROWS COUNT FOR A GIVEN A RESOURCE RESULT
    //  int db_num_rows(db resource ID $resourceID)
    //-----------------------------------//
    public function db_num_rows($resourceID) {
        try {
        $this->open_connection();
        }
        catch(exception $e) {
           return $e;
        }
        return mysql_num_rows($resourceID);
    }

}   //  END c l a s s   d b ( )

?>