<?
//-----------------------------------//
//  FACILITATES UPDATING A ZEN CART ORDER'S STATUS
//-----------------------------------//
error_reporting(E_ALL); //  DEBUG
include("inc/db.conn.php");
include("inc/db.func.php");
include("inc/xml.func.php");
include("inc/date.func.php");
include("inc/common.php");
$error = '';

//-----------------------------------//
//  CHECK GET STRING INFORMATION
//  $p = PASSWORD
//  $d = DATE [YYYY-MM-DD]
//  $o = ORDER ID
//-----------------------------------//

if(!isset($_GET['p']) || $_GET['p'] == '') {
    header ("content-type: text/xml");
    echo CreateErrorXML(2);
    exit;
}

if(!isset($_GET['d']) || $_GET['d'] == '') {
    header ("content-type: text/xml");
    echo CreateErrorXML(3);
    exit;
}

if(!isset($_GET['oid']) || $_GET['oid'] == '') {
    header ("content-type: text/xml");
    echo CreateErrorXML(5);
    exit;
}

//-----------------------------------//
//  CHECK PASSWORD
//-----------------------------------//
if(!$error && $_GET['p'] != PASSWORD){
    header ("content-type: text/xml");
    echo CreateErrorXML(4);
    exit;
}

//-----------------------------------//
//  CHECK DATE FORMAT
//-----------------------------------//
if(!$error && !IsValidDashDateFormat($_GET['d'])){
    header ("content-type: text/xml");
    echo CreateErrorXML(1);
    exit;
}

//-----------------------------------//
//  CHECK ORDER ID
//-----------------------------------//
if(!$error && !is_numeric($_GET['oid'])){
    header ("content-type: text/xml");
    echo CreateErrorXML(6);
    exit;
}

//-----------------------------------//
//  ATTEMPT TO UPDATE THE ORDER STATUS
//-----------------------------------//
$update_result = UpdateOrderStatus($_GET['oid'], $_GET['d']);
if($update_result){
    header ("content-type: text/xml");
    echo CreateErrorXML(8);
    exit;
} else {
    header ("content-type: text/xml");
    echo CreateErrorXML(7);
    exit;
}


?>