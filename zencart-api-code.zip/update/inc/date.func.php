<?
//-----------------------------------//
//  mixed IsValidDateFormat(int $postedDate)
//-----------------------------------//
function IsValidDashDateFormat($postedDate) {
   if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $postedDate, $datebit)) {
      //return checkdate($datebit[2] , $datebit[3] , $datebit[1]);
      return true;
   }
    return false;
}

?>