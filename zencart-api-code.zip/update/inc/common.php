<?
define("PASSWORD", "youraccesspasswordhere");   //  NEEDED TO ACESS THE API

//-----------------------------------//
//  ERROR CODES
//  0. [Not used]
//  1. Incorrect Date Format
//  2. No Password Supplied
//  3. No Date Supplied
//  4. Incorrect Password
//  5. No Order ID Supplied
//  6. Incorrect Order ID Format
//  7. Order Not Found
//  8. Success
//-----------------------------------//
$aXlateErrorCodes = array('','Incorrect Date Format','No Password Supplied','No Date Supplied','Incorrect Password','No Order ID Supplied','Incorrect Order ID Format','Order Not Found','Success');

?>