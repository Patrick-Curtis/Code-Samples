<?
// connect to db etc.
if(stristr($_SERVER['HTTP_HOST'],"localhost")){
	$main_hostname = "localhost";
	$db_name       = "zencartdbnamehere";
	$db_hostname   = "localhost";
	$db_username   = "root";
	$db_password   = "";
	$db_selected   = "";
} else {
    $main_hostname = "localhost";
    $db_name       = "zencartdbnamehere";
    $db_hostname   = "zencartdbnbostnamehere";
    $db_username   = "zencartdbusernamehere";
    $db_password   = "zencartdbpasswordhere";
	$db_selected   = "";
}

function db_start(){
    global $db;
    global $db_hostname;
    global $db_username;
    global $db_password;
    global $db_name;
    global $db_selected;

    //  GET THIS FILE'S LOCATION ON THE SERVER
    //  get_included_files() RETURNS AN ARRAY
    $included_files = get_included_files();
    foreach ($included_files as $file_path) {
        //  ASSUME FILENAME WE WANT ENDS IN db.php
        //  COULD BE ANY FILE NAME ENDING e.g (db.inc)
        if(stristr($file_path,'db.inc')){
            //echo "$file_path\n <br>";   //  DEBUG
            $offending_file = $file_path;
        }
    }
    $db = mysql_connect($db_hostname, $db_username, $db_password);
    if (!$db) {
        //ADDED TO NOTIFY USE OF DATABASE PROBLEMS FOR JOE
        $subject = '!! DATABASE CONNECTION ERROR !!';
        $body = "There was an error connecting to the $db_name database in file: $offending_file";
        $headers = "From: $db_name <sojournzen@sojournbeauty.com>\r\n" . "X-Priority: 1\r\n";
        //mail('pc@patcurtis.com',$subject,$body,$headers);
        //ADD mail() LINES HERE FOR ADDITIONAL NOTIFICATIONS
        die("Down for maintenance.");
    }
    $db_selected = mysql_select_db($db_name,$db);
    if (!$db_selected) {
        //ADDED TO NOTIFY USE OF DATABASE PROBLEMS FOR JOE
        $subject = '!! DATABASE SELECTION ERROR !!';
        $body = "There was an error selecting the $db_name database in file: $offending_file";
        $headers = "From: $db_name <sojournzen@sojournbeauty.com>\r\n" . "X-Priority: 1\r\n";
        //mail('pc@patcurtis.com',$subject,$body,$headers);
        //ADD mail() LINES HERE FOR ADDITIONAL NOTIFICATIONS
        die("Down for maintenance.");
    }

} // E N D   d b _ s t a r t ( )

// START DB EVERYTIME YOU INCLUDE THIS FILE
db_start();

$last__id = "";

function db_fetch_array($result) {

	return mysql_fetch_array($result);
}

function db_fetch_row($result) {

	return mysql_fetch_row($result);
}

function db_num_rows($result) {

    if($result){
        return mysql_num_rows($result);
    }
    return 0;
}

function db_query($query)
{
	global $db;
	$result = mysql_query($query,$db);
	if (!$result){
		echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here
		return false;
    }
//	echo $query ."<br>";
	return $result;
}

function db_insert_list($table, $data_list) {
    $query = "INSERT INTO $table (";
    while (list($column, $value) = each($data_list))
    {
        $columns[] = $column;
        $values[]  = "'" .mysql_real_escape_string($value). "'";
    }
    $query = $query
       . implode($columns, ", ")
       . ") VALUES ("
       . implode($values, ", ")
       . ")";
//    echo "Your query is: " .$query. "<br>";
	$ret = db_query($query);
	if (!$ret):
		echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here
		return false;
	endif;
	return $last__id = mysql_insert_id();
} // E N D   d b _ i n s e r t _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ e n d _ c o u n t )

function db_replace_list($table, $data_list) {
    $query = "REPLACE INTO $table (";
    while (list($column, $value) = each($data_list))
    {
        $columns[] = $column;
        $values[]  = "'" .mysql_real_escape_string($value). "'";
    }
    $query = $query
       . implode($columns, ", ")
       . ") VALUES ("
       . implode($values, ", ")
       . ")";
//    echo "Your query is: " .$query. "<br>";
	$ret = db_query($query);
	if (!$ret):
		echo mysql_errno().": ".mysql_error()."<BR>"; // need better error handling here
		return false;
	endif;
	return $last__id = mysql_insert_id();
} // E N D   d b _ i n s e r t _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ e n d _ c o u n t )

//-----------------------------------//
//  UPDATED FOR MYSQL 5 COMPATIBILITY
//-----------------------------------//
function db_update_list($table, $data_list, $id_name, $id) {
	$end_count = sizeof($data_list);
 	$query = "UPDATE `$table` SET ";
	$key = array_keys($data_list);
	$val = array_values($data_list);
	//$end_count = sizeof($key);
	for ($i = 1; $i < $end_count; $i++){
		if(($i +1) == $end_count){
            $query = $query. $key[$i]." = '" .mysql_real_escape_string($val[$i]). "'\n";
		}else{
			$query = $query. $key[$i]." = '" .mysql_real_escape_string($val[$i]). "', \n";
		}
        //echo "\$key[$i] --> ".$key[$i]."<br>";    //    DEBUG
	}
	$query = $query. "\n WHERE $id_name = $id";
  	//echo "<p>UPDATE QUERY RESULT IS <br><pre>$query</pre></p>";
	$ret = mysql_query($query);
	if (!$ret):
		echo mysql_errno().": ".mysql_error()."<BR>"; // NEED BETTER ERROR HANDLING HERE
		return false;
	endif;
	return $ret;
} // E N D   d b _ u p d a t e _ l i s t ( $ t a b l e ,   $ d a t a _ l i s t ,   $ i d _ n a m e ,   $ i d )

//-----------------------------------//
//  array get_enum_values( string $table, string $field )
//-----------------------------------//
function get_enum_values($table, $column){
    $enum = array();
    $enum_resource = mysql_query("SHOW COLUMNS FROM {$table} WHERE Field = '$column'");
    $row = db_fetch_row($enum_resource);
    //echo "\$row -> $row<br>";             //    DEBUG
    //print_r($row);                        //    DEBUG
    //  NOTE: ENUM VALUES MUST NOT HAVE COMMAS IN THEM OR THIS STRIPPING LINE WON'T WORK
    preg_match('/^enum\((.*)\)$/', $row[1], $matches);
    foreach( explode(',', $matches[1]) as $value ){
         $enum[] = trim( $value, "'" );
    }
    return $enum;
}

?>