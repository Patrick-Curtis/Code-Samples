<?
//-----------------------------------//
//  FUNCTIONS FOR USE IN CREATING XML CONTENT
//-----------------------------------//

//-----------------------------------//
//  string CreateErrorXML(int $error_code, string $more)
//-----------------------------------//
function CreateErrorXML($error_code=1, $more=''){
    GLOBAL $aXlateErrorCodes;
    $xmlout = '<?xml version="1.0"?>
<SojournBeautyOrders xml:lang="en-US">
    <ErrorInformation>
        <ErrorCode>'.$error_code.'</ErrorCode>
        <ErrorDescription>'.$aXlateErrorCodes[$error_code] . $more.'</ErrorDescription>
    </ErrorInformation>
</SojournBeautyOrders>
';

    return $xmlout;
}

?>