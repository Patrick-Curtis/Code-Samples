<?
define("PASSWORD", "youraccesspasswordhere");   //  NEEDED TO ACESS THE API
define("FETCHORDERLIMIT", "500");               //  DEFINES MAX RECORDS TO RETEIVE ON EACH POLLING

//-----------------------------------//
//  ERROR CODES
//  0. [Not used]
//  1. Incorrect Date Format
//  2. No Password Supplied
//  3. No Date Supplied
//  4. Incorrect Password
//  5. No Orders Found
//-----------------------------------//
$aXlateErrorCodes = array('','Incorrect Date Format','No Password Supplied','No Date Supplied','Incorrect Password','No Orders Found');

?>