<?
//-----------------------------------//
//  SQL FUNCTIONS
//  REQUIRES db.conn.php IN CALLING FILE
//-----------------------------------//

//-----------------------------------//
//  GET ORDER INFORMATION FOR PROVIDED DATE
//  mixed GetOrdersForDate(string $date, int [$limit])
//-----------------------------------//
function GetOrdersForDate($date, $limit=FETCHORDERLIMIT) {
    $sql = "
    SELECT *
    FROM orders
    WHERE date_purchased LIKE '$date%'
    AND orders_status = '2'
    GROUP BY orders_id
    ORDER BY date_purchased
    LIMIT $limit
    ";
    //echo "\$sql => $sql<br>";    //    DEBUG
    $resID = db_query($sql);
    if(db_num_rows($resID)){
        return $resID;
    }
    return false;

}

//-----------------------------------//
//  DEBUG PRINTS DB RESOURCE CONTENTS
//-----------------------------------//
function PrintDbResource($res) {
    if($res){
        while($r = db_fetch_row($res)){
        $max = sizeof($r);
            for($i = 0; $i < $max; $i++){
            echo $r[$i] . "<br>";    //    DEBUG
            }
        }
    } else {
        echo "Nothing to display!<br>";    //    DEBUG
    }
    return;
}

//-----------------------------------//
// mixed GetItemsForOrder(int $orders_id)
//-----------------------------------//
function GetItemsForOrder($orders_id) {
    $sql = "
    SELECT *
    FROM orders_products
    WHERE orders_id = '$orders_id'
    GROUP BY orders_products_id
    ";
    $resID = db_query($sql);
    if(db_num_rows($resID)){
        return $resID;
    }
    return false;
}
?>