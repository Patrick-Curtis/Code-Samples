<?
//-----------------------------------//
//  FACILITATES DOWNLOADING OF ZEN CART ORDER INFORMATION
//  FOR THIRD PARTY SHIPPING/FULLFILMENT PROCESSING
//-----------------------------------//
//error_reporting(E_ALL); //  DEBUG
include("inc/db.conn.php");
include("inc/db.func.php");
include("inc/xml.func.php");
include("inc/date.func.php");
include("inc/common.php");
$error = '';
$today = date("Ymd ");
//-----------------------------------//
//  CHECK GET STRING INFORMATION
//  $p = PASSWORD
//  $d = DATE [YYYMMDD]
//-----------------------------------//

if(!isset($_GET['p']) || $_GET['p'] == '') {
    header ("content-type: text/xml");
    echo CreateErrorXML(2);
    exit;
}

if(!isset($_GET['d']) || $_GET['d'] == '') {
    header ("content-type: text/xml");
    echo CreateErrorXML(3);
    exit;
}

//-----------------------------------//
//  CHECK PASSWORD
//-----------------------------------//
if(!$error && $_GET['p'] != PASSWORD){
    header ("content-type: text/xml");
    echo CreateErrorXML(4);
    exit;
}

//-----------------------------------//
//  CHECK DATE FORMAT
//-----------------------------------//
if(!$error && !IsValidDashDateFormat($_GET['d'])){
    header ("content-type: text/xml");
    echo CreateErrorXML(1);
    exit;
}

//-----------------------------------//
//  GET THE ORDERS IF ANY
//-----------------------------------//
$resOrders = GetOrdersForDate($_GET['d']);
//PrintDbResource($resOrders);    //  DEBUG
//-----------------------------------//
//  IF NO ORDERS FOR DATE LET THEM KNOW
//-----------------------------------//
if(!$resOrders){
    header ("content-type: text/xml");
    $moreinfo = ' for ' . $_GET['d'];
    echo CreateErrorXML(5, $moreinfo);
    exit;
} else {

//-----------------------------------//
//  PREP THE ORDER INFORMATION
//-----------------------------------//
$aXmlOut = '<?xml version="1.0"?>
<SojournBeautyOrders xml:lang="en-US">
    <ErrorInformation>
        <ErrorCode></ErrorCode>
        <ErrorDescription></ErrorDescription>
    </ErrorInformation>
';
while($r = db_fetch_array($resOrders)){
    $aXmlOut .= "<Order>\n";
    $aXmlOut .= "<OrderID>$r[orders_id]</OrderID>\n";
    $aXmlOut .= "<CustomerID>$r[customers_id]</CustomerID>\n";
    $aXmlOut .= "<CustomerName>$r[customers_name]</CustomerName>\n";
    $aXmlOut .= "<CustomerCompany>$r[customers_company]</CustomerCompany>\n";
    $aXmlOut .= "<CustomerPhone>$r[customers_telephone]</CustomerPhone>\n";
    $aXmlOut .= "<CustomerEmail>$r[customers_email_address]</CustomerEmail>\n";
    $aXmlOut .= "<ShipToName>$r[delivery_name]</ShipToName>\n";
    $aXmlOut .= "<ShipToCompany>$r[delivery_company]</ShipToCompany>\n";
    $aXmlOut .= "<ShipToAddress1>$r[delivery_street_address]</ShipToAddress1>\n";
    $aXmlOut .= "<ShipToAddress2>$r[delivery_suburb]</ShipToAddress2>\n";
    $aXmlOut .= "<ShipToCity>$r[delivery_city]</ShipToCity>\n";
    $aXmlOut .= "<ShipToState>$r[delivery_state]</ShipToState>\n";
    $aXmlOut .= "<ShipToCountry>$r[delivery_country]</ShipToCountry>\n";
    $aXmlOut .= "<ShipToPostalCode>$r[delivery_postcode]</ShipToPostalCode>\n";
    //  GET / ADD THE ITEMS ORDERED
    $resItems = GetItemsForOrder($r['orders_id']);
    while($items = db_fetch_array($resItems)){
        $aXmlOut .= "<OrderedItem>";
        $aXmlOut .= "<ProductID>$items[products_id]</ProductID>\n";
        $aXmlOut .= "<ProductName>$items[products_name]</ProductName>\n";
        $aXmlOut .= "<ProductQuantity>$items[products_quantity]</ProductQuantity>\n";
        $aXmlOut .= "</OrderedItem>\n";
    }
    $aXmlOut .= "</Order>\n";
}
$aXmlOut .= "</SojournBeautyOrders>\n";
header ("content-type: text/xml");
echo "$aXmlOut";
}

?>